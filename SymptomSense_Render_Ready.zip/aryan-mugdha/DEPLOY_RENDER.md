# Deploy SymptomSense to Render (single web service)

This project is configured to serve the React frontend and FastAPI backend from one Render web service.

## Quick steps
1. Extract this ZIP on your computer.
2. Upload the `aryan-mugdha` folder to a new GitHub repository (or push it with Git).
3. Sign in to Render and choose **New + → Blueprint**.
4. Connect the GitHub repository containing `render.yaml` at its root and apply the blueprint.
5. Wait for the build to finish. Render will provide the public `onrender.com` URL. Open that URL to use the website; add `/docs` to see the API documentation.

## Important
- The public URL is created by Render after you authorize deployment in your own account; it cannot be pre-created from this ZIP.
- The included SQLite database is local storage and may reset on free hosting/redeploy. For persistent data, configure a managed PostgreSQL database and set `DATABASE_URL` in Render.
- This is an educational demonstration, not a medical diagnostic service. Do not enter real patient-identifying or sensitive health information into a demo deployment.
- The app generates a secret key through Render's `generateValue` setting. Keep it private.
