const API_BASE = import.meta.env.VITE_API_URL || '';

const getHeaders = (isMultipart = false) => {
  const token = localStorage.getItem('symptomsense_token');
  const headers = {};
  if (token) {
    headers['Authorization'] = `Bearer ${token}`;
  }
  if (!isMultipart) {
    headers['Content-Type'] = 'application/json';
  }
  return headers;
};

const handleResponse = async (res) => {
  if (!res.ok) {
    let errorDetail = 'Request failed';
    try {
      const errJson = await res.json();
      errorDetail = errJson.detail || errJson.message || JSON.stringify(errJson);
    } catch {
      errorDetail = res.statusText;
    }
    throw new Error(errorDetail);
  }
  return res.json();
};

export const authApi = {
  login: async (credentials) => {
    const res = await fetch(`${API_BASE}/api/auth/login`, {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify(credentials)
    });
    return handleResponse(res);
  },

  register: async (userData) => {
    const res = await fetch(`${API_BASE}/api/auth/register`, {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify(userData)
    });
    return handleResponse(res);
  },

  getMe: async () => {
    const res = await fetch(`${API_BASE}/api/auth/me`, {
      headers: getHeaders()
    });
    return handleResponse(res);
  },

  updateConsent: async (consent_given) => {
    const res = await fetch(`${API_BASE}/api/auth/consent`, {
      method: 'POST',
      headers: getHeaders(),
      body: JSON.stringify({ consent_given })
    });
    return handleResponse(res);
  },

  deleteMyData: async () => {
    const res = await fetch(`${API_BASE}/api/auth/delete-my-data`, {
      method: 'DELETE',
      headers: getHeaders()
    });
    return handleResponse(res);
  }
};

export const profileApi = {
  getProfile: async () => {
    const res = await fetch(`${API_BASE}/api/profile`, {
      headers: getHeaders()
    });
    return handleResponse(res);
  },

  updateProfile: async (profileData) => {
    const res = await fetch(`${API_BASE}/api/profile`, {
      method: 'PUT',
      headers: getHeaders(),
      body: JSON.stringify(profileData)
    });
    return handleResponse(res);
  }
};

export const recordsApi = {
  getRecords: async (record_type = null) => {
    const url = record_type 
      ? `${API_BASE}/api/records?record_type=${record_type}`
      : `${API_BASE}/api/records`;
    const res = await fetch(url, {
      headers: getHeaders()
    });
    return handleResponse(res);
  },

  createRecord: async (recordData) => {
    const res = await fetch(`${API_BASE}/api/records`, {
      method: 'POST',
      headers: getHeaders(),
      body: JSON.stringify(recordData)
    });
    return handleResponse(res);
  },

  uploadReport: async (formData) => {
    const res = await fetch(`${API_BASE}/api/records/upload`, {
      method: 'POST',
      headers: getHeaders(true),
      body: formData
    });
    return handleResponse(res);
  },

  deleteRecord: async (id) => {
    const res = await fetch(`${API_BASE}/api/records/${id}`, {
      method: 'DELETE',
      headers: getHeaders()
    });
    return handleResponse(res);
  }
};

export const predictApi = {
  getSymptomsList: async () => {
    const res = await fetch(`${API_BASE}/api/predict/symptoms-list`);
    return handleResponse(res);
  },

  getMetrics: async () => {
    const res = await fetch(`${API_BASE}/api/predict/metrics`);
    return handleResponse(res);
  },

  predictSymptoms: async (payload) => {
    const res = await fetch(`${API_BASE}/api/predict`, {
      method: 'POST',
      headers: getHeaders(),
      body: JSON.stringify(payload)
    });
    return handleResponse(res);
  },

  getHistory: async () => {
    const res = await fetch(`${API_BASE}/api/predict/history`, {
      headers: getHeaders()
    });
    return handleResponse(res);
  },

  getPredictionById: async (id) => {
    const res = await fetch(`${API_BASE}/api/predict/${id}`, {
      headers: getHeaders()
    });
    return handleResponse(res);
  }
};

export const analyticsApi = {
  getDashboard: async () => {
    const res = await fetch(`${API_BASE}/api/analytics/dashboard`, {
      headers: getHeaders()
    });
    return handleResponse(res);
  }
};

export const fhirApi = {
  exportBundle: async () => {
    const res = await fetch(`${API_BASE}/api/fhir/export`, {
      headers: getHeaders()
    });
    if (!res.ok) throw new Error('FHIR export failed');
    return res.json();
  },

  importBundle: async (bundle) => {
    const res = await fetch(`${API_BASE}/api/fhir/import`, {
      method: 'POST',
      headers: getHeaders(),
      body: JSON.stringify({ bundle })
    });
    return handleResponse(res);
  }
};

export { API_BASE };
