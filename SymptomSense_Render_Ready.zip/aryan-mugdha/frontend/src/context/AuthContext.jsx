import React, { createContext, useContext, useState, useEffect } from 'react';
import { authApi } from '../services/api';

const AuthContext = createContext(null);

export const DEMO_ACCOUNTS = [
  {
    email: 'john.doe@example.com',
    name: 'John Doe',
    role: 'Patient (Cardiometabolic)',
    tags: ['Age 58', 'Hypertension', 'Type 2 Diabetes', 'High BP'],
    desc: 'Senior patient with chronic hypertension & glycemic history.'
  },
  {
    email: 'jane.smith@example.com',
    name: 'Jane Smith',
    role: 'Patient (Allergy & Asthma)',
    tags: ['Age 28', 'Asthma', 'Allergies', 'Penicillin Allergy'],
    desc: 'Young adult with active allergic rhinitis and asthma flare-up history.'
  },
  {
    email: 'alex.wong@example.com',
    name: 'Alex Wong',
    role: 'Patient (Healthy Baseline)',
    tags: ['Age 34', 'Active', 'No Chronic Conditions'],
    desc: 'Healthy adult baseline profile with optimal lab vitals.'
  }
];

export const AuthProvider = ({ children }) => {
  const [user, setUser] = useState(null);
  const [token, setToken] = useState(localStorage.getItem('symptomsense_token'));
  const [loading, setLoading] = useState(true);
  const [toast, setToast] = useState(null);

  const showToast = (message, type = 'info') => {
    setToast({ message, type, id: Date.now() });
    setTimeout(() => setToast(null), 4000);
  };

  useEffect(() => {
    const initAuth = async () => {
      const savedToken = localStorage.getItem('symptomsense_token');
      if (savedToken) {
        try {
          const userData = await authApi.getMe();
          setUser(userData);
        } catch (err) {
          console.error('Session expired or invalid:', err);
          localStorage.removeItem('symptomsense_token');
          setToken(null);
          setUser(null);
        }
      }
      setLoading(false);
    };

    initAuth();
  }, []);

  const login = async (email, password) => {
    try {
      const data = await authApi.login({ email, password });
      localStorage.setItem('symptomsense_token', data.access_token);
      setToken(data.access_token);
      const userData = await authApi.getMe();
      setUser(userData);
      showToast(`Welcome back, ${userData.full_name}!`, 'success');
      return userData;
    } catch (err) {
      showToast(err.message || 'Login failed', 'error');
      throw err;
    }
  };

  const register = async (userData) => {
    try {
      const data = await authApi.register(userData);
      localStorage.setItem('symptomsense_token', data.access_token);
      setToken(data.access_token);
      const me = await authApi.getMe();
      setUser(me);
      showToast('Registration successful! Profile initialized.', 'success');
      return me;
    } catch (err) {
      showToast(err.message || 'Registration failed', 'error');
      throw err;
    }
  };

  const logout = () => {
    localStorage.removeItem('symptomsense_token');
    setToken(null);
    setUser(null);
    showToast('You have been securely signed out.', 'info');
  };

  const switchDemoUser = async (demoEmail) => {
    try {
      setLoading(true);
      await login(demoEmail, 'Password123!');
      setLoading(false);
    } catch (err) {
      setLoading(false);
      showToast(`Failed to switch to ${demoEmail}: ${err.message}`, 'error');
    }
  };

  return (
    <AuthContext.Provider
      value={{
        user,
        token,
        loading,
        login,
        register,
        logout,
        switchDemoUser,
        showToast,
        toast,
        isAuthenticated: !!user
      }}
    >
      {children}
      
      {/* Toast Notification Alert */}
      {toast && (
        <div className="fixed bottom-6 right-6 z-50 animate-slide-up flex items-center space-x-3 px-4 py-3 rounded-xl shadow-2xl backdrop-blur-md border text-sm font-medium transition-all"
             style={{
               backgroundColor: toast.type === 'error' ? 'rgba(239, 68, 68, 0.95)' :
                                toast.type === 'success' ? 'rgba(16, 185, 129, 0.95)' :
                                'rgba(6, 182, 212, 0.95)',
               borderColor: 'rgba(255, 255, 255, 0.2)',
               color: '#FFFFFF'
             }}>
          <span>{toast.message}</span>
        </div>
      )}
    </AuthContext.Provider>
  );
};

export const useAuth = () => {
  const context = useContext(AuthContext);
  if (!context) {
    throw new Error('useAuth must be used within an AuthProvider');
  }
  return context;
};
