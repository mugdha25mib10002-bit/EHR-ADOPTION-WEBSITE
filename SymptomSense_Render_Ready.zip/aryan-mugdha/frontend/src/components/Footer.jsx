import React from 'react';
import { Link } from 'react-router-dom';
import { Activity, ShieldCheck, Heart, Lock, Database } from 'lucide-react';

const Footer = () => {
  return (
    <footer className="bg-slate-950 border-t border-slate-900 text-slate-400 text-xs py-10 px-4 sm:px-6 lg:px-8 mt-20 no-print">
      <div className="max-w-7xl mx-auto grid grid-cols-1 md:grid-cols-4 gap-8 mb-8">
        
        {/* Brand & Mission */}
        <div className="space-y-3 md:col-span-1">
          <div className="flex items-center space-x-2">
            <div className="w-7 h-7 rounded-lg bg-gradient-to-tr from-cyan-500 to-teal-400 flex items-center justify-center text-slate-950 font-bold">
              <Activity className="w-4 h-4 text-slate-950" />
            </div>
            <span className="font-display font-bold text-white text-base tracking-tight">SymptomSense</span>
          </div>
          <p className="text-slate-400 text-xs leading-relaxed">
            Next-generation multi-modal health prediction engine synthesizing active symptoms and longitudinal electronic health record history with explainable AI.
          </p>
          <div className="flex items-center space-x-2 text-[11px] text-emerald-400 font-medium">
            <ShieldCheck className="w-3.5 h-3.5" />
            <span>HIPAA-Ready & Encrypted</span>
          </div>
        </div>

        {/* Quick Links */}
        <div className="space-y-2">
          <h4 className="font-bold text-white uppercase text-[11px] tracking-wider">Features</h4>
          <ul className="space-y-1.5 text-xs">
            <li><Link to="/checker" className="hover:text-cyan-300 transition">Symptom Checker</Link></li>
            <li><Link to="/dashboard" className="hover:text-cyan-300 transition">Clinical Dashboard</Link></li>
            <li><Link to="/timeline" className="hover:text-cyan-300 transition">EHR History Timeline</Link></li>
            <li><Link to="/profile" className="hover:text-cyan-300 transition">Health Profile</Link></li>
            <li><Link to="/fhir" className="hover:text-cyan-300 transition">HL7 FHIR Interoperability</Link></li>
          </ul>
        </div>

        {/* Safety & Compliance */}
        <div className="space-y-2">
          <h4 className="font-bold text-white uppercase text-[11px] tracking-wider">Privacy & Trust</h4>
          <ul className="space-y-1.5 text-xs">
            <li><Link to="/privacy" className="hover:text-cyan-300 transition">Encryption Standards (AES-256)</Link></li>
            <li><Link to="/privacy" className="hover:text-cyan-300 transition">Consent Management</Link></li>
            <li><Link to="/privacy" className="hover:text-cyan-300 transition">Data Purge (Delete My Data)</Link></li>
            <li><span className="text-slate-500">ICD-10 & LOINC Standard Mappings</span></li>
          </ul>
        </div>

        {/* Medical Notice */}
        <div className="space-y-2 bg-slate-900/60 p-4 rounded-2xl border border-slate-800/80">
          <h4 className="font-bold text-amber-300 uppercase text-[11px] tracking-wider flex items-center gap-1.5">
            <Lock className="w-3 h-3" /> Medical Notice
          </h4>
          <p className="text-[11px] text-slate-400 leading-normal">
            SymptomSense does not offer definitive medical diagnosis or treatment plans. In case of severe pain, respiratory distress, or stroke symptoms, please call emergency services (911 / 112) immediately.
          </p>
        </div>

      </div>

      <div className="max-w-7xl mx-auto pt-6 border-t border-slate-900/80 flex flex-col sm:flex-row items-center justify-between text-[11px] text-slate-500 gap-3">
        <p>© {new Date().getFullYear()} SymptomSense Health AI Inc. All rights reserved.</p>
        <p className="flex items-center gap-1">
          Designed for Clinical Precision & Patient Privacy
        </p>
      </div>
    </footer>
  );
};

export default Footer;
