import React, { useState } from 'react';
import { AlertCircle, X, ShieldCheck } from 'lucide-react';

const DisclaimerBanner = () => {
  const [dismissed, setDismissed] = useState(false);

  if (dismissed) return null;

  return (
    <div className="bg-gradient-to-r from-amber-500/10 via-amber-500/15 to-amber-500/10 border-b border-amber-500/30 text-amber-200 text-xs py-2 px-4 shadow-sm relative no-print">
      <div className="max-w-7xl mx-auto flex items-center justify-between gap-3">
        <div className="flex items-center space-x-2 text-amber-300">
          <AlertCircle className="w-4 h-4 flex-shrink-0 text-amber-400 animate-pulse" />
          <p className="leading-tight">
            <strong className="font-semibold text-amber-200">Clinical Disclaimer:</strong> SymptomSense is an AI research and educational assistant that detects potential condition probabilities. It does <span className="underline font-bold">NOT</span> provide a certified medical diagnosis. If you are experiencing a medical emergency, call 911 / 112 immediately.
          </p>
        </div>
        <button
          onClick={() => setDismissed(true)}
          className="text-amber-400/70 hover:text-amber-200 p-1 rounded transition-colors"
          title="Dismiss disclaimer"
          aria-label="Dismiss disclaimer"
        >
          <X className="w-3.5 h-3.5" />
        </button>
      </div>
    </div>
  );
};

export default DisclaimerBanner;
