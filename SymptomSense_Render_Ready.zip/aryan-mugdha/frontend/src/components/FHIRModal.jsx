import React, { useState, useEffect } from 'react';
import { Database, Download, Upload, Copy, Check, X, FileText, RefreshCw, AlertCircle } from 'lucide-react';
import { fhirApi } from '../services/api';
import { useAuth } from '../context/AuthContext';

const FHIRModal = ({ isOpen, onClose, onImportSuccess }) => {
  const { showToast } = useAuth();
  const [activeTab, setActiveTab] = useState('export');
  const [fhirData, setFhirData] = useState(null);
  const [loading, setLoading] = useState(false);
  const [copied, setCopied] = useState(false);
  
  // Import State
  const [importJsonText, setImportJsonText] = useState('');
  const [importLoading, setImportLoading] = useState(false);
  const [importResult, setImportResult] = useState(null);

  useEffect(() => {
    if (isOpen && activeTab === 'export') {
      fetchFhirExport();
    }
  }, [isOpen, activeTab]);

  const fetchFhirExport = async () => {
    setLoading(true);
    try {
      const data = await fhirApi.exportBundle();
      setFhirData(data);
    } catch (err) {
      showToast('Failed to generate FHIR Bundle: ' + err.message, 'error');
    } finally {
      setLoading(false);
    }
  };

  const handleDownloadJson = () => {
    if (!fhirData) return;
    const blob = new Blob([JSON.stringify(fhirData, null, 2)], { type: 'application/json' });
    const url = URL.createObjectURL(blob);
    const a = document.createElement('a');
    a.href = url;
    a.download = `symptomsense_fhir_r4_bundle.json`;
    document.body.appendChild(a);
    a.click();
    document.body.removeChild(a);
    URL.revokeObjectURL(url);
    showToast('FHIR R4 Bundle downloaded successfully!', 'success');
  };

  const handleCopyJson = () => {
    if (!fhirData) return;
    navigator.clipboard.writeText(JSON.stringify(fhirData, null, 2));
    setCopied(true);
    setTimeout(() => setCopied(false), 2500);
    showToast('FHIR Bundle JSON copied to clipboard!', 'success');
  };

  const handleFileUpload = (e) => {
    const file = e.target.files[0];
    if (!file) return;
    const reader = new FileReader();
    reader.onload = (event) => {
      setImportJsonText(event.target.result);
    };
    reader.readAsText(file);
  };

  const handleImportSubmit = async () => {
    if (!importJsonText.trim()) {
      showToast('Please paste valid FHIR JSON or upload a file.', 'error');
      return;
    }

    setImportLoading(true);
    setImportResult(null);
    try {
      const parsed = JSON.parse(importJsonText);
      const res = await fhirApi.importBundle(parsed);
      setImportResult(res);
      showToast(`Successfully imported ${res.records_imported} EHR observations!`, 'success');
      if (onImportSuccess) onImportSuccess();
    } catch (err) {
      showToast('Import Error: ' + err.message, 'error');
    } finally {
      setImportLoading(false);
    }
  };

  if (!isOpen) return null;

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-slate-950/85 backdrop-blur-md animate-fade-in no-print">
      <div className="bg-slate-900 border border-slate-700 rounded-3xl max-w-3xl w-full p-6 sm:p-8 shadow-2xl text-white relative overflow-hidden flex flex-col max-h-[90vh]">
        
        {/* Header */}
        <div className="flex items-center justify-between border-b border-slate-800 pb-4 mb-5">
          <div className="flex items-center space-x-3">
            <div className="p-2.5 bg-indigo-500/20 border border-indigo-500/40 rounded-2xl text-indigo-400">
              <Database className="w-6 h-6" />
            </div>
            <div>
              <h3 className="text-xl font-bold text-white flex items-center gap-2">
                HL7 FHIR R4 Interoperability Center
              </h3>
              <p className="text-xs text-slate-400">
                Standardized clinical data exchange (Patient, Condition, Observation, MedicationStatement).
              </p>
            </div>
          </div>
          <button
            onClick={onClose}
            className="p-1.5 text-slate-400 hover:text-white rounded-xl hover:bg-slate-800 transition"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        {/* Action Mode Tabs */}
        <div className="flex items-center space-x-2 mb-4">
          <button
            onClick={() => setActiveTab('export')}
            className={`flex items-center space-x-2 px-4 py-2 rounded-xl text-xs font-bold transition ${
              activeTab === 'export'
                ? 'bg-cyan-500/20 text-cyan-300 border border-cyan-500/50 shadow-sm shadow-cyan-500/20'
                : 'text-slate-400 hover:text-white hover:bg-slate-800/60'
            }`}
          >
            <Download className="w-4 h-4" />
            <span>Export FHIR JSON Bundle</span>
          </button>
          <button
            onClick={() => setActiveTab('import')}
            className={`flex items-center space-x-2 px-4 py-2 rounded-xl text-xs font-bold transition ${
              activeTab === 'import'
                ? 'bg-teal-500/20 text-teal-300 border border-teal-500/50 shadow-sm shadow-teal-500/20'
                : 'text-slate-400 hover:text-white hover:bg-slate-800/60'
            }`}
          >
            <Upload className="w-4 h-4" />
            <span>Import External FHIR Data</span>
          </button>
        </div>

        {/* Body Content */}
        <div className="flex-1 overflow-y-auto custom-scrollbar pr-1">
          {activeTab === 'export' ? (
            <div className="space-y-4">
              <div className="flex items-center justify-between">
                <span className="text-xs font-semibold text-slate-300">
                  {loading ? 'Generating FHIR Bundle...' : `Generated Bundle (${fhirData?.entry?.length || 0} Standard Resources)`}
                </span>
                <div className="flex items-center space-x-2">
                  <button
                    onClick={handleCopyJson}
                    disabled={loading || !fhirData}
                    className="flex items-center space-x-1.5 px-3 py-1.5 bg-slate-800 hover:bg-slate-700 text-slate-200 border border-slate-700 rounded-xl text-xs font-medium transition disabled:opacity-50"
                  >
                    {copied ? <Check className="w-3.5 h-3.5 text-emerald-400" /> : <Copy className="w-3.5 h-3.5" />}
                    <span>{copied ? 'Copied!' : 'Copy JSON'}</span>
                  </button>
                  <button
                    onClick={handleDownloadJson}
                    disabled={loading || !fhirData}
                    className="flex items-center space-x-1.5 px-3.5 py-1.5 bg-gradient-to-r from-cyan-500 to-teal-500 hover:from-cyan-400 hover:to-teal-400 text-slate-950 font-bold rounded-xl text-xs shadow-md transition disabled:opacity-50"
                  >
                    <Download className="w-3.5 h-3.5" />
                    <span>Download .JSON</span>
                  </button>
                </div>
              </div>

              {loading ? (
                <div className="h-64 flex flex-col items-center justify-center space-y-3 text-slate-400">
                  <RefreshCw className="w-8 h-8 animate-spin text-cyan-400" />
                  <span className="text-xs font-medium">Serializing Patient EHR into HL7 FHIR standard...</span>
                </div>
              ) : (
                <pre className="bg-slate-950 p-4 rounded-2xl border border-slate-800 text-[11px] font-mono text-cyan-300/90 overflow-x-auto max-h-96 custom-scrollbar leading-relaxed">
                  {JSON.stringify(fhirData, null, 2)}
                </pre>
              )}
            </div>
          ) : (
            <div className="space-y-4">
              <div className="p-3 bg-slate-950 border border-slate-800 rounded-2xl text-xs text-slate-300">
                <p className="font-semibold text-teal-300 mb-1">Import Guidelines:</p>
                <p>Upload a standard HL7 FHIR R4 Bundle JSON. SymptomSense will automatically parse Patient demographics, Conditions, Medications, and LOINC-coded Observations into your health profile.</p>
              </div>

              <div>
                <label className="block text-xs font-semibold text-slate-300 mb-1.5">
                  Upload FHIR Bundle JSON File
                </label>
                <input
                  type="file"
                  accept=".json,application/json"
                  onChange={handleFileUpload}
                  className="w-full text-xs text-slate-400 file:mr-3 file:py-2 file:px-4 file:rounded-xl file:border-0 file:text-xs file:font-semibold file:bg-slate-800 file:text-cyan-300 hover:file:bg-slate-700 cursor-pointer"
                />
              </div>

              <div>
                <label className="block text-xs font-semibold text-slate-300 mb-1.5">
                  Or Paste Raw FHIR JSON Payload
                </label>
                <textarea
                  value={importJsonText}
                  onChange={(e) => setImportJsonText(e.target.value)}
                  placeholder='{"resourceType": "Bundle", "type": "collection", "entry": [...] }'
                  rows={8}
                  className="w-full bg-slate-950 border border-slate-800 rounded-2xl p-3 text-xs font-mono text-cyan-300 focus:outline-none focus:border-teal-500 custom-scrollbar"
                />
              </div>

              {importResult && (
                <div className="p-3.5 bg-emerald-950/40 border border-emerald-500/40 rounded-2xl text-xs text-emerald-200 space-y-1">
                  <div className="font-bold text-emerald-300 flex items-center gap-1.5">
                    <Check className="w-4 h-4" /> Import Complete
                  </div>
                  <p>Successfully processed {importResult.records_imported} observation records.</p>
                  <ul className="list-disc list-inside text-[11px] text-emerald-300/80 space-y-0.5">
                    {importResult.details?.map((d, i) => (
                      <li key={i}>{d}</li>
                    ))}
                  </ul>
                </div>
              )}

              <div className="flex justify-end pt-2">
                <button
                  onClick={handleImportSubmit}
                  disabled={importLoading || !importJsonText.trim()}
                  className="flex items-center space-x-2 px-5 py-2.5 bg-teal-500 hover:bg-teal-400 text-slate-950 font-bold rounded-xl text-xs shadow-lg shadow-teal-500/20 transition disabled:opacity-50"
                >
                  {importLoading ? <RefreshCw className="w-4 h-4 animate-spin" /> : <Upload className="w-4 h-4" />}
                  <span>{importLoading ? 'Processing FHIR...' : 'Import & Sync to EHR'}</span>
                </button>
              </div>
            </div>
          )}
        </div>
      </div>
    </div>
  );
};

export default FHIRModal;
