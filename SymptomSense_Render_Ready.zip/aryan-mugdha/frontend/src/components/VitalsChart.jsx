import React, { useState } from 'react';
import {
  LineChart,
  Line,
  AreaChart,
  Area,
  BarChart,
  Bar,
  XAxis,
  YAxis,
  CartesianGrid,
  Tooltip,
  ResponsiveContainer,
  ReferenceLine,
  Legend
} from 'recharts';
import { Activity, Droplet, Heart, TrendingUp } from 'lucide-react';

const CustomTooltip = ({ active, payload, label }) => {
  if (active && payload && payload.length) {
    return (
      <div className="bg-slate-900 border border-slate-700 p-3 rounded-xl shadow-2xl text-xs space-y-1">
        <p className="font-semibold text-slate-300 border-b border-slate-800 pb-1">{label}</p>
        {payload.map((entry, index) => (
          <div key={index} className="flex items-center justify-between space-x-4">
            <span style={{ color: entry.color }} className="font-medium">
              {entry.name}:
            </span>
            <span className="font-mono font-bold text-white">
              {entry.value} {entry.unit || ''}
            </span>
          </div>
        ))}
      </div>
    );
  }
  return null;
};

const VitalsChart = ({ vitalsData }) => {
  const [activeTab, setActiveTab] = useState('bp');

  const bpData = vitalsData?.bp_series || [];
  const glucoseData = vitalsData?.glucose_series || [];
  const cholData = vitalsData?.cholesterol_series || [];

  return (
    <div className="glass-card p-6 space-y-5">
      {/* Header & Metric Tabs */}
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-3 border-b border-slate-800 pb-4">
        <div>
          <div className="flex items-center space-x-2">
            <TrendingUp className="w-5 h-5 text-cyan-400" />
            <h3 className="text-lg font-bold text-white">EHR Vitals & Lab Trends</h3>
          </div>
          <p className="text-xs text-slate-400 mt-0.5">
            Longitudinal monitoring of clinical laboratory observations and physical vitals.
          </p>
        </div>

        {/* Tab Selector */}
        <div className="flex items-center bg-slate-950/80 p-1 rounded-xl border border-slate-800 self-start sm:self-auto">
          <button
            onClick={() => setActiveTab('bp')}
            className={`flex items-center space-x-1.5 px-3 py-1.5 rounded-lg text-xs font-semibold transition ${
              activeTab === 'bp'
                ? 'bg-cyan-500/20 text-cyan-300 border border-cyan-500/40 shadow-sm'
                : 'text-slate-400 hover:text-white'
            }`}
          >
            <Activity className="w-3.5 h-3.5" />
            <span>Blood Pressure</span>
          </button>
          <button
            onClick={() => setActiveTab('glucose')}
            className={`flex items-center space-x-1.5 px-3 py-1.5 rounded-lg text-xs font-semibold transition ${
              activeTab === 'glucose'
                ? 'bg-teal-500/20 text-teal-300 border border-teal-500/40 shadow-sm'
                : 'text-slate-400 hover:text-white'
            }`}
          >
            <Droplet className="w-3.5 h-3.5" />
            <span>Blood Glucose</span>
          </button>
          <button
            onClick={() => setActiveTab('lipids')}
            className={`flex items-center space-x-1.5 px-3 py-1.5 rounded-lg text-xs font-semibold transition ${
              activeTab === 'lipids'
                ? 'bg-indigo-500/20 text-indigo-300 border border-indigo-500/40 shadow-sm'
                : 'text-slate-400 hover:text-white'
            }`}
          >
            <Heart className="w-3.5 h-3.5" />
            <span>Cholesterol</span>
          </button>
        </div>
      </div>

      {/* Charts Display */}
      <div className="h-64 sm:h-72 w-full">
        {activeTab === 'bp' && (
          bpData.length === 0 ? (
            <div className="h-full flex items-center justify-center text-xs text-slate-500">
              No blood pressure records logged yet. Add your first record in the EHR Timeline.
            </div>
          ) : (
            <ResponsiveContainer width="100%" height="100%">
              <LineChart data={bpData} margin={{ top: 10, right: 20, left: -10, bottom: 0 }}>
                <CartesianGrid strokeDasharray="3 3" stroke="#1E293B" />
                <XAxis dataKey="date" stroke="#64748B" tick={{ fontSize: 11 }} />
                <YAxis domain={[50, 190]} stroke="#64748B" tick={{ fontSize: 11 }} />
                <Tooltip content={<CustomTooltip />} />
                <Legend wrapperStyle={{ fontSize: '11px', paddingTop: '8px' }} />
                <ReferenceLine y={120} stroke="#10B981" strokeDasharray="3 3" label={{ value: 'Normal Sys (120)', fill: '#10B981', fontSize: 10 }} />
                <ReferenceLine y={80} stroke="#06B6D4" strokeDasharray="3 3" label={{ value: 'Normal Dia (80)', fill: '#06B6D4', fontSize: 10 }} />
                <ReferenceLine y={140} stroke="#EF4444" strokeDasharray="4 4" label={{ value: 'Stage 1 HTN (140)', fill: '#EF4444', fontSize: 10 }} />
                <Line type="monotone" dataKey="systolic" name="Systolic BP" stroke="#06B6D4" strokeWidth={3} dot={{ r: 4, fill: '#06B6D4' }} activeDot={{ r: 6 }} />
                <Line type="monotone" dataKey="diastolic" name="Diastolic BP" stroke="#14B8A6" strokeWidth={2.5} dot={{ r: 4, fill: '#14B8A6' }} />
              </LineChart>
            </ResponsiveContainer>
          )
        )}

        {activeTab === 'glucose' && (
          glucoseData.length === 0 ? (
            <div className="h-full flex items-center justify-center text-xs text-slate-500">
              No blood glucose records logged yet.
            </div>
          ) : (
            <ResponsiveContainer width="100%" height="100%">
              <AreaChart data={glucoseData} margin={{ top: 10, right: 20, left: -10, bottom: 0 }}>
                <defs>
                  <linearGradient id="fastingGrad" x1="0" y1="0" x2="0" y2="1">
                    <stop offset="5%" stopColor="#14B8A6" stopOpacity={0.4}/>
                    <stop offset="95%" stopColor="#14B8A6" stopOpacity={0.0}/>
                  </linearGradient>
                </defs>
                <CartesianGrid strokeDasharray="3 3" stroke="#1E293B" />
                <XAxis dataKey="date" stroke="#64748B" tick={{ fontSize: 11 }} />
                <YAxis domain={[60, 240]} stroke="#64748B" tick={{ fontSize: 11 }} />
                <Tooltip content={<CustomTooltip />} />
                <Legend wrapperStyle={{ fontSize: '11px', paddingTop: '8px' }} />
                <ReferenceLine y={100} stroke="#10B981" strokeDasharray="3 3" label={{ value: 'Normal Fasting (100)', fill: '#10B981', fontSize: 10 }} />
                <ReferenceLine y={126} stroke="#F59E0B" strokeDasharray="3 3" label={{ value: 'Diabetic Threshold (126)', fill: '#F59E0B', fontSize: 10 }} />
                <Area type="monotone" dataKey="fasting" name="Fasting Glucose (mg/dL)" stroke="#14B8A6" strokeWidth={2.5} fillOpacity={1} fill="url(#fastingGrad)" />
                {glucoseData.some(d => d.postprandial) && (
                  <Line type="monotone" dataKey="postprandial" name="Postprandial (mg/dL)" stroke="#F59E0B" strokeWidth={2} dot={{ r: 4 }} />
                )}
              </AreaChart>
            </ResponsiveContainer>
          )
        )}

        {activeTab === 'lipids' && (
          cholData.length === 0 ? (
            <div className="h-full flex items-center justify-center text-xs text-slate-500">
              No cholesterol panels logged yet.
            </div>
          ) : (
            <ResponsiveContainer width="100%" height="100%">
              <BarChart data={cholData} margin={{ top: 10, right: 20, left: -10, bottom: 0 }}>
                <CartesianGrid strokeDasharray="3 3" stroke="#1E293B" />
                <XAxis dataKey="date" stroke="#64748B" tick={{ fontSize: 11 }} />
                <YAxis stroke="#64748B" tick={{ fontSize: 11 }} />
                <Tooltip content={<CustomTooltip />} />
                <Legend wrapperStyle={{ fontSize: '11px', paddingTop: '8px' }} />
                <ReferenceLine y={200} stroke="#EF4444" strokeDasharray="3 3" label={{ value: 'Max Desirable (200)', fill: '#EF4444', fontSize: 10 }} />
                <Bar dataKey="total" name="Total Cholesterol (mg/dL)" fill="#6366F1" radius={[4, 4, 0, 0]} />
                <Bar dataKey="ldl" name="LDL (Bad) (mg/dL)" fill="#F43F5E" radius={[4, 4, 0, 0]} />
                <Bar dataKey="hdl" name="HDL (Good) (mg/dL)" fill="#10B981" radius={[4, 4, 0, 0]} />
              </BarChart>
            </ResponsiveContainer>
          )
        )}
      </div>
    </div>
  );
};

export default VitalsChart;
