import React, { useState } from 'react';
import { Link, useLocation } from 'react-router-dom';
import { 
  Activity, 
  Stethoscope, 
  User, 
  Clock, 
  Database, 
  ShieldCheck, 
  LayoutDashboard, 
  LogOut, 
  LogIn, 
  UserPlus, 
  ChevronDown, 
  AlertTriangle,
  Menu,
  X,
  Sparkles
} from 'lucide-react';
import { useAuth, DEMO_ACCOUNTS } from '../context/AuthContext';
import EmergencyModal from './EmergencyModal';

const Navbar = () => {
  const { user, logout, switchDemoUser, isAuthenticated } = useAuth();
  const location = useLocation();
  const [demoDropdown, setDemoDropdown] = useState(false);
  const [mobileMenuOpen, setMobileMenuOpen] = useState(false);
  const [showEmergency, setShowEmergency] = useState(false);

  const navLinks = [
    { name: 'Dashboard', path: '/dashboard', icon: LayoutDashboard, authRequired: true },
    { name: 'Symptom Checker', path: '/checker', icon: Stethoscope, highlight: true },
    { name: 'Health Profile', path: '/profile', icon: User, authRequired: true },
    { name: 'EHR Timeline', path: '/timeline', icon: Clock, authRequired: true },
    { name: 'FHIR Hub', path: '/fhir', icon: Database, authRequired: true },
    { name: 'Privacy & Security', path: '/privacy', icon: ShieldCheck }
  ];

  const isActive = (path) => location.pathname === path;

  return (
    <>
      <header className="sticky top-0 z-40 bg-slate-950/80 backdrop-blur-xl border-b border-slate-800/80 shadow-lg no-print">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="flex items-center justify-between h-16">
            
            {/* Logo */}
            <Link to="/" className="flex items-center space-x-3 group">
              <div className="w-10 h-10 rounded-xl bg-gradient-to-tr from-cyan-600 via-teal-500 to-emerald-400 p-0.5 shadow-lg shadow-cyan-500/20 group-hover:scale-105 transition-transform duration-300">
                <div className="w-full h-full bg-slate-950 rounded-[10px] flex items-center justify-center">
                  <Activity className="w-5 h-5 text-cyan-400 group-hover:text-teal-300 transition-colors" />
                </div>
              </div>
              <div className="flex flex-col">
                <span className="font-display font-extrabold text-xl tracking-tight bg-gradient-to-r from-cyan-400 via-teal-300 to-emerald-400 bg-clip-text text-transparent">
                  SymptomSense
                </span>
                <span className="text-[10px] tracking-wider text-slate-400 uppercase font-semibold -mt-1">
                  EHR + ML Health Engine
                </span>
              </div>
            </Link>

            {/* Desktop Navigation Links */}
            <nav className="hidden lg:flex items-center space-x-1">
              {navLinks.map((link) => {
                if (link.authRequired && !isAuthenticated) return null;
                const Icon = link.icon;
                const active = isActive(link.path);

                return (
                  <Link
                    key={link.path}
                    to={link.path}
                    className={`flex items-center space-x-1.5 px-3 py-2 rounded-xl text-xs font-semibold transition-all duration-200 ${
                      active
                        ? 'bg-cyan-500/15 text-cyan-300 border border-cyan-500/30 shadow-sm shadow-cyan-500/10'
                        : link.highlight
                        ? 'text-cyan-400 hover:text-cyan-300 hover:bg-slate-800/60'
                        : 'text-slate-300 hover:text-white hover:bg-slate-800/60'
                    }`}
                  >
                    <Icon className={`w-3.5 h-3.5 ${active ? 'text-cyan-400' : 'text-slate-400'}`} />
                    <span>{link.name}</span>
                  </Link>
                );
              })}
            </nav>

            {/* Right Action Section */}
            <div className="hidden sm:flex items-center space-x-3">
              
              {/* Emergency SOS Shortcut */}
              <button
                onClick={() => setShowEmergency(true)}
                className="flex items-center space-x-1.5 px-3 py-1.5 bg-rose-500/15 hover:bg-rose-500/25 border border-rose-500/40 text-rose-300 rounded-xl text-xs font-bold transition-all shadow-sm shadow-rose-500/10 active:scale-95"
                title="Emergency SOS Guidance"
              >
                <AlertTriangle className="w-3.5 h-3.5 text-rose-400 animate-pulse" />
                <span>Emergency SOS</span>
              </button>

              {/* Demo Accounts Switcher Dropdown */}
              <div className="relative">
                <button
                  onClick={() => setDemoDropdown(!demoDropdown)}
                  className="flex items-center space-x-1 px-2.5 py-1.5 bg-slate-800/80 hover:bg-slate-800 border border-slate-700/80 text-slate-200 rounded-xl text-xs font-medium transition"
                  title="Switch between demo profiles"
                >
                  <Sparkles className="w-3.5 h-3.5 text-amber-400" />
                  <span className="hidden md:inline">Demo Profiles</span>
                  <ChevronDown className="w-3 h-3 text-slate-400" />
                </button>

                {demoDropdown && (
                  <div className="absolute right-0 mt-2 w-72 bg-slate-900 border border-slate-700 rounded-2xl shadow-2xl p-2 z-50 animate-slide-up text-xs">
                    <div className="px-3 py-2 border-b border-slate-800 text-[11px] font-semibold text-slate-400 uppercase tracking-wider">
                      Switch Demo Patient Account
                    </div>
                    <div className="space-y-1 mt-1">
                      {DEMO_ACCOUNTS.map((acc) => (
                        <button
                          key={acc.email}
                          onClick={() => {
                            switchDemoUser(acc.email);
                            setDemoDropdown(false);
                          }}
                          className={`w-full text-left p-2.5 rounded-xl transition flex flex-col space-y-1 ${
                            user?.email === acc.email
                              ? 'bg-cyan-500/20 border border-cyan-500/40 text-cyan-200'
                              : 'hover:bg-slate-800 text-slate-200'
                          }`}
                        >
                          <div className="flex items-center justify-between">
                            <span className="font-bold text-white">{acc.name}</span>
                            <span className="text-[10px] px-1.5 py-0.5 bg-slate-800 rounded text-slate-300">
                              {acc.email === 'john.doe@example.com' ? 'Cardio/DM' : acc.email === 'jane.smith@example.com' ? 'Asthma/Allergy' : 'Healthy'}
                            </span>
                          </div>
                          <p className="text-[11px] text-slate-400 leading-tight">{acc.desc}</p>
                        </button>
                      ))}
                    </div>
                  </div>
                )}
              </div>

              {/* User Account / Auth Buttons */}
              {isAuthenticated ? (
                <div className="flex items-center space-x-2 border-l border-slate-800 pl-3">
                  <Link
                    to="/profile"
                    className="flex items-center space-x-2 px-2.5 py-1.5 rounded-xl bg-slate-800/60 border border-slate-700/60 hover:border-cyan-500/40 transition"
                  >
                    <div className="w-6 h-6 rounded-full bg-gradient-to-tr from-cyan-500 to-teal-400 flex items-center justify-center text-slate-950 font-bold text-xs">
                      {user?.full_name?.charAt(0) || 'U'}
                    </div>
                    <span className="text-xs font-medium text-slate-200 max-w-[100px] truncate">
                      {user?.full_name?.split(' ')[0]}
                    </span>
                  </Link>
                  <button
                    onClick={logout}
                    className="p-1.5 text-slate-400 hover:text-rose-300 hover:bg-rose-500/10 rounded-xl transition"
                    title="Sign out"
                  >
                    <LogOut className="w-4 h-4" />
                  </button>
                </div>
              ) : (
                <div className="flex items-center space-x-2 border-l border-slate-800 pl-3">
                  <Link
                    to="/login"
                    className="flex items-center space-x-1 px-3 py-1.5 text-xs font-semibold text-slate-300 hover:text-white rounded-xl hover:bg-slate-800 transition"
                  >
                    <LogIn className="w-3.5 h-3.5" />
                    <span>Sign In</span>
                  </Link>
                  <Link
                    to="/register"
                    className="flex items-center space-x-1 px-3 py-1.5 text-xs font-bold text-slate-950 bg-gradient-to-r from-cyan-400 to-teal-300 hover:from-cyan-300 hover:to-teal-200 rounded-xl shadow-md shadow-cyan-500/20 transition"
                  >
                    <UserPlus className="w-3.5 h-3.5" />
                    <span>Get Started</span>
                  </Link>
                </div>
              )}
            </div>

            {/* Mobile Hamburger Button */}
            <div className="flex lg:hidden items-center space-x-2">
              <button
                onClick={() => setShowEmergency(true)}
                className="p-1.5 bg-rose-500/20 text-rose-400 border border-rose-500/30 rounded-lg text-xs"
              >
                <AlertTriangle className="w-4 h-4" />
              </button>
              <button
                onClick={() => setMobileMenuOpen(!mobileMenuOpen)}
                className="p-2 text-slate-400 hover:text-white hover:bg-slate-800 rounded-xl transition"
              >
                {mobileMenuOpen ? <X className="w-6 h-6" /> : <Menu className="w-6 h-6" />}
              </button>
            </div>
          </div>
        </div>

        {/* Mobile Dropdown Menu */}
        {mobileMenuOpen && (
          <div className="lg:hidden border-t border-slate-800 bg-slate-950/95 backdrop-blur-2xl px-4 py-4 space-y-2 animate-slide-up">
            {navLinks.map((link) => {
              if (link.authRequired && !isAuthenticated) return null;
              const Icon = link.icon;
              return (
                <Link
                  key={link.path}
                  to={link.path}
                  onClick={() => setMobileMenuOpen(false)}
                  className={`flex items-center space-x-2.5 px-3 py-2.5 rounded-xl text-sm font-medium ${
                    isActive(link.path)
                      ? 'bg-cyan-500/15 text-cyan-300 border border-cyan-500/30'
                      : 'text-slate-300 hover:bg-slate-800'
                  }`}
                >
                  <Icon className="w-4 h-4 text-cyan-400" />
                  <span>{link.name}</span>
                </Link>
              );
            })}

            <div className="pt-3 border-t border-slate-800 space-y-2">
              <div className="text-xs font-semibold text-slate-400 px-1">Demo Accounts</div>
              <div className="grid grid-cols-3 gap-2">
                {DEMO_ACCOUNTS.map((acc) => (
                  <button
                    key={acc.email}
                    onClick={() => {
                      switchDemoUser(acc.email);
                      setMobileMenuOpen(false);
                    }}
                    className="p-2 bg-slate-900 border border-slate-700 text-slate-200 text-xs rounded-xl font-medium"
                  >
                    {acc.name.split(' ')[0]}
                  </button>
                ))}
              </div>
            </div>

            <div className="pt-3 border-t border-slate-800 flex items-center justify-between">
              {isAuthenticated ? (
                <div className="flex items-center justify-between w-full">
                  <span className="text-xs text-slate-300">{user?.email}</span>
                  <button
                    onClick={() => {
                      logout();
                      setMobileMenuOpen(false);
                    }}
                    className="text-xs text-rose-400 font-semibold"
                  >
                    Sign Out
                  </button>
                </div>
              ) : (
                <div className="grid grid-cols-2 gap-2 w-full">
                  <Link
                    to="/login"
                    onClick={() => setMobileMenuOpen(false)}
                    className="text-center py-2 text-xs font-semibold bg-slate-800 rounded-xl text-white"
                  >
                    Sign In
                  </Link>
                  <Link
                    to="/register"
                    onClick={() => setMobileMenuOpen(false)}
                    className="text-center py-2 text-xs font-bold bg-cyan-400 text-slate-950 rounded-xl"
                  >
                    Register
                  </Link>
                </div>
              )}
            </div>
          </div>
        )}
      </header>

      {/* Emergency Modal Instance */}
      <EmergencyModal
        isOpen={showEmergency}
        onClose={() => setShowEmergency(false)}
        triggerReason="Direct user emergency assistance request"
      />
    </>
  );
};

export default Navbar;
