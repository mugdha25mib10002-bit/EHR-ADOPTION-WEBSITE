import React from 'react';
import { HelpCircle, CheckCircle2, MinusCircle, UserCheck, HeartPulse, Stethoscope, ArrowUpRight, ArrowDownRight } from 'lucide-react';

const ExplainabilityTree = ({ factors = [], conditionName = 'Predicted Condition', patientSummary = null }) => {
  const positiveFactors = factors.filter(f => f.impact === 'positive' || f.contribution > 0);
  const negativeFactors = factors.filter(f => f.impact === 'negative' || f.contribution < 0);

  const getTypeBadge = (type) => {
    switch (type) {
      case 'ehr_history':
        return { label: 'EHR History Factor', color: 'bg-indigo-500/20 text-indigo-300 border-indigo-500/40', icon: UserCheck };
      case 'vital_sign':
        return { label: 'Lab / Vital Risk', color: 'bg-amber-500/20 text-amber-300 border-amber-500/40', icon: HeartPulse };
      case 'symptom':
      default:
        return { label: 'Active Symptom', color: 'bg-cyan-500/20 text-cyan-300 border-cyan-500/40', icon: Stethoscope };
    }
  };

  return (
    <div className="glass-card p-6 space-y-6">
      {/* Header */}
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-2 border-b border-slate-800 pb-4">
        <div>
          <div className="flex items-center space-x-2">
            <HelpCircle className="w-5 h-5 text-cyan-400" />
            <h3 className="text-lg font-bold text-white">Clinical Explainability (SHAP Tree Analysis)</h3>
          </div>
          <p className="text-xs text-slate-400 mt-0.5">
            Transparent breakdown showing why the model correlated your symptoms & EHR history with <strong className="text-cyan-300">{conditionName}</strong>.
          </p>
        </div>
        <span className="text-[11px] px-3 py-1 rounded-full bg-slate-800 border border-slate-700 text-slate-300 font-mono self-start sm:self-auto">
          Random Forest Feature Weights
        </span>
      </div>

      {/* Patient History Integration Status Banner */}
      {patientSummary && (
        <div className="bg-slate-900/90 border border-indigo-500/30 rounded-xl p-3.5 text-xs text-slate-300 flex flex-wrap items-center gap-3">
          <span className="font-semibold text-indigo-300 flex items-center gap-1">
            <UserCheck className="w-4 h-4 text-indigo-400" />
            Active EHR Profile:
          </span>
          <span className="bg-slate-800 px-2 py-0.5 rounded text-slate-200">Age: {patientSummary.age}</span>
          <span className="bg-slate-800 px-2 py-0.5 rounded text-slate-200">Gender: {patientSummary.gender}</span>
          {patientSummary.hypertension_history && (
            <span className="bg-amber-500/15 border border-amber-500/30 text-amber-300 px-2 py-0.5 rounded font-medium">
              Hypertension History
            </span>
          )}
          {patientSummary.diabetes_history && (
            <span className="bg-amber-500/15 border border-amber-500/30 text-amber-300 px-2 py-0.5 rounded font-medium">
              Diabetes History
            </span>
          )}
          {patientSummary.asthma_history && (
            <span className="bg-cyan-500/15 border border-cyan-500/30 text-cyan-300 px-2 py-0.5 rounded font-medium">
              Asthma History
            </span>
          )}
          {patientSummary.allergies_history && (
            <span className="bg-teal-500/15 border border-teal-500/30 text-teal-300 px-2 py-0.5 rounded font-medium">
              Allergies Recorded
            </span>
          )}
        </div>
      )}

      {/* Evidence Columns */}
      <div className="grid grid-cols-1 md:grid-cols-2 gap-5">
        
        {/* Supporting Positive Evidence */}
        <div className="space-y-3">
          <div className="flex items-center space-x-2 text-emerald-400 font-semibold text-xs uppercase tracking-wider">
            <ArrowUpRight className="w-4 h-4" />
            <span>Strongest Supporting Evidence ({positiveFactors.length})</span>
          </div>

          <div className="space-y-2.5">
            {positiveFactors.length === 0 ? (
              <p className="text-xs text-slate-500 italic">No specific positive drivers identified.</p>
            ) : (
              positiveFactors.map((item, idx) => {
                const badge = getTypeBadge(item.type);
                const Icon = badge.icon;
                const magnitude = Math.min(100, Math.abs(item.contribution));

                return (
                  <div
                    key={idx}
                    className="p-3 bg-slate-900/80 border border-emerald-500/20 hover:border-emerald-500/40 rounded-xl transition duration-200"
                  >
                    <div className="flex items-center justify-between text-xs mb-1.5">
                      <div className="flex items-center space-x-1.5">
                        <CheckCircle2 className="w-3.5 h-3.5 text-emerald-400 flex-shrink-0" />
                        <span className="font-semibold text-white">{item.feature_label}</span>
                      </div>
                      <span className="font-mono font-bold text-emerald-400 text-xs">
                        +{item.contribution}%
                      </span>
                    </div>

                    <div className="flex items-center justify-between gap-3">
                      <div className="w-full bg-slate-800 rounded-full h-1.5 overflow-hidden">
                        <div
                          className="bg-gradient-to-r from-emerald-400 to-teal-400 h-full rounded-full"
                          style={{ width: `${magnitude}%` }}
                        />
                      </div>
                      <span className={`text-[10px] px-2 py-0.5 rounded-full border whitespace-nowrap font-medium ${badge.color}`}>
                        {badge.label}
                      </span>
                    </div>
                  </div>
                );
              })
            )}
          </div>
        </div>

        {/* Counter-Evidence / Missing Negative Indicators */}
        <div className="space-y-3">
          <div className="flex items-center space-x-2 text-slate-400 font-semibold text-xs uppercase tracking-wider">
            <ArrowDownRight className="w-4 h-4 text-slate-400" />
            <span>Missing Typical Indicators ({negativeFactors.length})</span>
          </div>

          <div className="space-y-2.5">
            {negativeFactors.length === 0 ? (
              <div className="p-3 bg-slate-900/60 border border-slate-800 rounded-xl text-xs text-slate-400">
                All primary classic indicators for this condition are currently present.
              </div>
            ) : (
              negativeFactors.map((item, idx) => {
                return (
                  <div
                    key={idx}
                    className="p-3 bg-slate-900/60 border border-slate-800 rounded-xl text-xs"
                  >
                    <div className="flex items-center justify-between mb-1.5">
                      <div className="flex items-center space-x-1.5">
                        <MinusCircle className="w-3.5 h-3.5 text-slate-400 flex-shrink-0" />
                        <span className="font-medium text-slate-300">{item.feature_label}</span>
                      </div>
                      <span className="font-mono text-slate-400 font-semibold">
                        {item.contribution}%
                      </span>
                    </div>
                    <div className="w-full bg-slate-800 rounded-full h-1.5 overflow-hidden">
                      <div
                        className="bg-slate-600 h-full rounded-full"
                        style={{ width: `${Math.min(100, Math.abs(item.contribution))}%` }}
                      />
                    </div>
                  </div>
                );
              })
            )}
          </div>
        </div>

      </div>
    </div>
  );
};

export default ExplainabilityTree;
