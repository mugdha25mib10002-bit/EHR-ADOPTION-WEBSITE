import React from 'react';
import { AlertTriangle, PhoneCall, HeartCrack, Wind, Activity, X } from 'lucide-react';

const EmergencyModal = ({ isOpen, onClose, triggerReason }) => {
  if (!isOpen) return null;

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-slate-950/85 backdrop-blur-md animate-fade-in no-print">
      <div className="bg-slate-900 border-2 border-rose-500/80 rounded-3xl max-w-lg w-full p-6 sm:p-8 shadow-2xl shadow-rose-500/20 text-white relative overflow-hidden animate-slide-up">
        {/* Glow Header Accent */}
        <div className="absolute top-0 left-0 right-0 h-2 bg-gradient-to-r from-rose-600 via-red-500 to-amber-500 animate-pulse" />

        <div className="flex items-start justify-between mb-4">
          <div className="flex items-center space-x-3">
            <div className="p-3 bg-rose-500/20 border border-rose-500/40 rounded-2xl text-rose-400">
              <AlertTriangle className="w-8 h-8 animate-bounce" />
            </div>
            <div>
              <span className="text-xs uppercase tracking-wider font-bold text-rose-400 bg-rose-500/10 px-2.5 py-0.5 rounded-full border border-rose-500/30">
                Critical Red Flag Detected
              </span>
              <h2 className="text-xl font-bold text-white mt-1">Medical Emergency Alert</h2>
            </div>
          </div>
          <button
            onClick={onClose}
            className="text-slate-400 hover:text-white p-1 rounded-lg hover:bg-slate-800 transition"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        <div className="bg-rose-950/40 border border-rose-800/50 rounded-2xl p-4 mb-5 text-sm text-rose-200">
          <p className="font-semibold text-rose-100 flex items-center gap-2">
            <HeartCrack className="w-4 h-4 text-rose-400" />
            Trigger: {triggerReason || 'Severe acute life-threatening symptoms detected'}
          </p>
          <p className="text-xs text-rose-300/80 mt-1">
            Symptoms of acute coronary event, stroke (FAST warning), or severe respiratory compromise require immediate emergency medical care.
          </p>
        </div>

        <div className="space-y-3 mb-6">
          <h4 className="text-xs uppercase tracking-wider text-slate-400 font-semibold">Immediate Safety Actions:</h4>
          <ul className="space-y-2 text-xs text-slate-300">
            <li className="flex items-center gap-2">
              <span className="w-1.5 h-1.5 rounded-full bg-rose-400"></span>
              <strong>Call Emergency Services immediately (911 in US / 112 in EU / 102/108 in India).</strong>
            </li>
            <li className="flex items-center gap-2">
              <span className="w-1.5 h-1.5 rounded-full bg-rose-400"></span>
              <strong>Stop all physical exertion</strong> and sit or lie in a comfortable semi-upright position.
            </li>
            <li className="flex items-center gap-2">
              <span className="w-1.5 h-1.5 rounded-full bg-rose-400"></span>
              <strong>Do not drive yourself</strong> to the hospital; await paramedics with medical equipment.
            </li>
            <li className="flex items-center gap-2">
              <span className="w-1.5 h-1.5 rounded-full bg-rose-400"></span>
              Have someone stay with you and unlock the front door for emergency responders.
            </li>
          </ul>
        </div>

        {/* Emergency Dial Buttons */}
        <div className="grid grid-cols-1 sm:grid-cols-2 gap-3 mb-4">
          <a
            href="tel:911"
            className="flex items-center justify-center gap-2 py-3 px-4 bg-rose-600 hover:bg-rose-500 text-white font-bold rounded-xl shadow-lg shadow-rose-600/30 transition transform hover:-translate-y-0.5 active:translate-y-0"
          >
            <PhoneCall className="w-4 h-4" />
            Call 911 (US / Canada)
          </a>
          <a
            href="tel:112"
            className="flex items-center justify-center gap-2 py-3 px-4 bg-slate-800 hover:bg-slate-700 text-slate-100 border border-slate-700 font-bold rounded-xl transition transform hover:-translate-y-0.5"
          >
            <PhoneCall className="w-4 h-4 text-cyan-400" />
            Call 112 (EU / Global)
          </a>
        </div>

        <button
          onClick={onClose}
          className="w-full text-center text-xs text-slate-400 hover:text-slate-200 py-2 transition underline underline-offset-2"
        >
          I understand the risks. Continue with SymptomSense assessment.
        </button>
      </div>
    </div>
  );
};

export default EmergencyModal;
