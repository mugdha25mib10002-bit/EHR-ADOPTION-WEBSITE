import React from 'react';

const ConfidenceBar = ({ confidence, urgency, showLabel = true, size = 'md' }) => {
  const rounded = Math.round(confidence * 10) / 10;

  const getGradient = (val) => {
    if (val >= 80) return 'from-teal-400 to-emerald-500';
    if (val >= 50) return 'from-cyan-400 to-teal-500';
    if (val >= 25) return 'from-amber-400 to-orange-500';
    return 'from-slate-400 to-slate-500';
  };

  const getUrgencyBadge = (urg) => {
    switch (urg) {
      case 'Emergency':
        return 'bg-rose-500/20 text-rose-300 border-rose-500/50 shadow-sm shadow-rose-500/20 animate-pulse';
      case 'High':
        return 'bg-amber-500/20 text-amber-300 border-amber-500/40 shadow-sm shadow-amber-500/10';
      case 'Medium':
        return 'bg-yellow-500/15 text-yellow-300 border-yellow-500/30';
      case 'Low':
      default:
        return 'bg-emerald-500/15 text-emerald-300 border-emerald-500/30';
    }
  };

  const heightClass = size === 'lg' ? 'h-3.5' : size === 'sm' ? 'h-1.5' : 'h-2.5';

  return (
    <div className="w-full space-y-1.5">
      {showLabel && (
        <div className="flex items-center justify-between text-xs font-semibold">
          <div className="flex items-center space-x-2">
            <span className="text-slate-300">Model Confidence</span>
            {urgency && (
              <span className={`text-[10px] px-2 py-0.5 rounded-full border font-bold uppercase tracking-wider ${getUrgencyBadge(urgency)}`}>
                {urgency} Urgency
              </span>
            )}
          </div>
          <span className="font-display font-bold text-white text-sm">
            {rounded}%
          </span>
        </div>
      )}

      {/* Progress Track */}
      <div className={`w-full bg-slate-800/80 rounded-full overflow-hidden p-0.5 border border-slate-700/50 ${heightClass}`}>
        <div
          className={`h-full rounded-full bg-gradient-to-r ${getGradient(rounded)} transition-all duration-1000 ease-out`}
          style={{ width: `${Math.min(100, Math.max(4, rounded))}%` }}
        />
      </div>
    </div>
  );
};

export default ConfidenceBar;
