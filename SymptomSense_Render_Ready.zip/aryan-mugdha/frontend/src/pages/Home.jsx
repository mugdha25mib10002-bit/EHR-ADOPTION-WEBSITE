import React from 'react';
import { Link, useNavigate } from 'react-router-dom';
import { 
  Stethoscope, 
  Activity, 
  ShieldCheck, 
  Database, 
  Sparkles, 
  ArrowRight, 
  HeartPulse, 
  FileText, 
  BrainCircuit, 
  CheckCircle,
  AlertTriangle,
  Users
} from 'lucide-react';
import { useAuth, DEMO_ACCOUNTS } from '../context/AuthContext';

const Home = () => {
  const { switchDemoUser, isAuthenticated } = useAuth();
  const navigate = useNavigate();

  const handleDemoSelect = async (email) => {
    await switchDemoUser(email);
    navigate('/checker');
  };

  return (
    <div className="space-y-24 py-8">
      
      {/* Hero Section */}
      <section className="relative overflow-hidden pt-6 pb-12">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 text-center space-y-8">
          
          {/* Top Medical Badge */}
          <div className="inline-flex items-center space-x-2 px-4 py-1.5 rounded-full bg-cyan-500/10 border border-cyan-500/30 text-cyan-300 text-xs font-semibold animate-fade-in shadow-sm shadow-cyan-500/20">
            <Sparkles className="w-3.5 h-3.5 text-cyan-400 animate-pulse" />
            <span>Multi-Modal Health Intelligence & EHR Synthesis</span>
          </div>

          {/* Main Headline */}
          <div className="space-y-4 max-w-4xl mx-auto">
            <h1 className="text-4xl sm:text-6xl lg:text-7xl font-extrabold tracking-tight font-display text-white leading-[1.1]">
              Predict Health Conditions with <br />
              <span className="bg-gradient-to-r from-cyan-400 via-teal-300 to-emerald-400 bg-clip-text text-transparent">
                Active Symptoms + EHR History
              </span>
            </h1>
            <p className="text-base sm:text-xl text-slate-300 max-w-2xl mx-auto leading-relaxed font-normal">
              SymptomSense doesn't just look at isolated symptoms in a vacuum. It fuses your current complaints with your longitudinal Electronic Health Record (past diagnoses, chronic risks, lab vitals) using explainable Machine Learning.
            </p>
          </div>

          {/* Primary Action Buttons */}
          <div className="flex flex-col sm:flex-row items-center justify-center gap-4 pt-2">
            <Link
              to="/checker"
              className="w-full sm:w-auto flex items-center justify-center space-x-2 px-8 py-4 rounded-2xl bg-gradient-to-r from-cyan-500 to-teal-400 hover:from-cyan-400 hover:to-teal-300 text-slate-950 font-extrabold text-base shadow-xl shadow-cyan-500/25 transition transform hover:-translate-y-0.5 active:translate-y-0"
            >
              <Stethoscope className="w-5 h-5" />
              <span>Start Symptom Check</span>
              <ArrowRight className="w-4 h-4" />
            </Link>
            
            {isAuthenticated ? (
              <Link
                to="/dashboard"
                className="w-full sm:w-auto flex items-center justify-center space-x-2 px-7 py-4 rounded-2xl bg-slate-900/90 hover:bg-slate-800 text-slate-100 border border-slate-700/80 font-bold text-base transition transform hover:-translate-y-0.5"
              >
                <Activity className="w-5 h-5 text-cyan-400" />
                <span>Open Patient Dashboard</span>
              </Link>
            ) : (
              <Link
                to="/register"
                className="w-full sm:w-auto flex items-center justify-center space-x-2 px-7 py-4 rounded-2xl bg-slate-900/90 hover:bg-slate-800 text-slate-100 border border-slate-700/80 font-bold text-base transition transform hover:-translate-y-0.5"
              >
                <Users className="w-5 h-5 text-teal-400" />
                <span>Create Free Health Profile</span>
              </Link>
            )}
          </div>

          {/* Key Metrics Stats Bar */}
          <div className="grid grid-cols-2 md:grid-cols-4 gap-4 max-w-4xl mx-auto pt-8">
            <div className="glass-card p-4 text-center">
              <div className="text-2xl sm:text-3xl font-extrabold font-display text-cyan-300">99.7%</div>
              <div className="text-xs text-slate-400 font-medium mt-0.5">Model Test Accuracy</div>
            </div>
            <div className="glass-card p-4 text-center">
              <div className="text-2xl sm:text-3xl font-extrabold font-display text-teal-300">30+</div>
              <div className="text-xs text-slate-400 font-medium mt-0.5">Clinical Conditions</div>
            </div>
            <div className="glass-card p-4 text-center">
              <div className="text-2xl sm:text-3xl font-extrabold font-display text-emerald-300">240+</div>
              <div className="text-xs text-slate-400 font-medium mt-0.5">Categorized Symptoms</div>
            </div>
            <div className="glass-card p-4 text-center">
              <div className="text-2xl sm:text-3xl font-extrabold font-display text-indigo-300">HL7 FHIR</div>
              <div className="text-xs text-slate-400 font-medium mt-0.5">R4 Standard Ready</div>
            </div>
          </div>

        </div>
      </section>

      {/* 1-Click Demo Profiles Showcase */}
      <section className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="text-center max-w-2xl mx-auto mb-10 space-y-2">
          <span className="text-xs font-bold uppercase tracking-wider text-cyan-400">Instant Evaluation</span>
          <h2 className="text-2xl sm:text-3xl font-extrabold text-white">
            Test Pre-Seeded Clinical Profiles
          </h2>
          <p className="text-xs sm:text-sm text-slate-400">
            Click any profile below to instantly load their longitudinal EHR history and launch the symptom checker.
          </p>
        </div>

        <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
          {DEMO_ACCOUNTS.map((acc, index) => (
            <div
              key={acc.email}
              className="glass-card glass-card-hover p-6 flex flex-col justify-between space-y-4 border-slate-800 relative group"
            >
              <div className="space-y-3">
                <div className="flex items-center justify-between">
                  <div className="w-10 h-10 rounded-xl bg-gradient-to-tr from-cyan-500/20 to-teal-500/20 border border-cyan-500/30 flex items-center justify-center text-cyan-300 font-bold">
                    {index + 1}
                  </div>
                  <span className="text-[10px] px-2.5 py-0.5 rounded-full bg-slate-800 text-cyan-300 border border-slate-700 font-semibold">
                    {acc.role}
                  </span>
                </div>

                <div>
                  <h3 className="text-lg font-bold text-white group-hover:text-cyan-300 transition">
                    {acc.name}
                  </h3>
                  <p className="text-xs text-slate-400 mt-1 leading-relaxed">
                    {acc.desc}
                  </p>
                </div>

                <div className="flex flex-wrap gap-1.5 pt-1">
                  {acc.tags.map((tag, i) => (
                    <span
                      key={i}
                      className="text-[10px] px-2 py-0.5 bg-slate-800/80 rounded-md text-slate-300 border border-slate-700/50"
                    >
                      {tag}
                    </span>
                  ))}
                </div>
              </div>

              <button
                onClick={() => handleDemoSelect(acc.email)}
                className="w-full flex items-center justify-center space-x-1.5 py-2.5 px-4 bg-slate-800/80 hover:bg-cyan-500 text-slate-200 hover:text-slate-950 font-bold text-xs rounded-xl border border-slate-700 hover:border-cyan-400 transition duration-200"
              >
                <span>Load Profile & Check</span>
                <ArrowRight className="w-3.5 h-3.5" />
              </button>
            </div>
          ))}
        </div>
      </section>

      {/* How It Works (Multi-Modal Pipeline) */}
      <section className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="text-center max-w-2xl mx-auto mb-12 space-y-2">
          <span className="text-xs font-bold uppercase tracking-wider text-teal-400">Architecture</span>
          <h2 className="text-2xl sm:text-3xl font-extrabold text-white">
            How SymptomSense Evaluates Risk
          </h2>
          <p className="text-xs sm:text-sm text-slate-400">
            A three-tier clinical inference engine combining real-time symptoms with historical risk factors.
          </p>
        </div>

        <div className="grid grid-cols-1 md:grid-cols-3 gap-8">
          
          {/* Step 1 */}
          <div className="glass-card p-6 space-y-4 border-slate-800 relative">
            <div className="w-12 h-12 rounded-2xl bg-cyan-500/15 border border-cyan-500/30 flex items-center justify-center text-cyan-400">
              <Stethoscope className="w-6 h-6" />
            </div>
            <h3 className="text-lg font-bold text-white">1. Multi-Select & Free-Text</h3>
            <p className="text-xs text-slate-400 leading-relaxed">
              Search over 240 structured symptoms or simply describe your feelings in natural language. Our NLP extractor matches clinical symptoms and flags urgent red-flags.
            </p>
          </div>

          {/* Step 2 */}
          <div className="glass-card p-6 space-y-4 border-slate-800 relative">
            <div className="w-12 h-12 rounded-2xl bg-teal-500/15 border border-teal-500/30 flex items-center justify-center text-teal-400">
              <Database className="w-6 h-6" />
            </div>
            <h3 className="text-lg font-bold text-white">2. Longitudinal EHR Fusion</h3>
            <p className="text-xs text-slate-400 leading-relaxed">
              The engine automatically combines your demographic baseline, chronic illnesses, active medications, family history, and latest BP / glucose readings into the feature vector.
            </p>
          </div>

          {/* Step 3 */}
          <div className="glass-card p-6 space-y-4 border-slate-800 relative">
            <div className="w-12 h-12 rounded-2xl bg-emerald-500/15 border border-emerald-500/30 flex items-center justify-center text-emerald-400">
              <BrainCircuit className="w-6 h-6" />
            </div>
            <h3 className="text-lg font-bold text-white">3. Explainable Diagnostic Output</h3>
            <p className="text-xs text-slate-400 leading-relaxed">
              Receive top-5 probable conditions with confidence meters, urgency grading (Low/Med/High/Emergency), specialist referral, home care steps, and transparent SHAP feature weights.
            </p>
          </div>

        </div>
      </section>

      {/* Safety & Red Flag Callout */}
      <section className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="bg-gradient-to-r from-rose-950/40 via-slate-900 to-rose-950/40 border border-rose-500/30 rounded-3xl p-8 sm:p-10 flex flex-col md:flex-row items-center justify-between gap-6 shadow-2xl">
          <div className="space-y-3 max-w-2xl">
            <div className="flex items-center space-x-2 text-rose-400 text-xs font-bold uppercase tracking-wider">
              <AlertTriangle className="w-4 h-4" />
              <span>Real-Time Patient Safety Guardian</span>
            </div>
            <h3 className="text-xl sm:text-2xl font-bold text-white">
              Emergency Red-Flag Detection Active 24/7
            </h3>
            <p className="text-xs sm:text-sm text-slate-300 leading-relaxed">
              If our system detects acute coronary symptoms, signs of stroke (FAST rules), severe respiratory failure, or internal bleeding, it immediately bypasses standard triage and displays emergency dialer guidance.
            </p>
          </div>
          <Link
            to="/checker"
            className="flex-shrink-0 px-6 py-3.5 bg-rose-600 hover:bg-rose-500 text-white font-bold text-xs rounded-xl shadow-lg shadow-rose-600/30 transition transform hover:-translate-y-0.5"
          >
            Launch Safety Checker
          </Link>
        </div>
      </section>

    </div>
  );
};

export default Home;
