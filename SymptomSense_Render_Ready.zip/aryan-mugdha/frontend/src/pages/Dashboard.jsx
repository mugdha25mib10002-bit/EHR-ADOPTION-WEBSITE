import React, { useState, useEffect } from 'react';
import { Link } from 'react-router-dom';
import { 
  Activity, 
  Stethoscope, 
  Clock, 
  Calendar, 
  Bell, 
  CheckCircle2, 
  TrendingUp, 
  Heart, 
  Droplet, 
  AlertTriangle, 
  FileText, 
  ArrowRight,
  ShieldCheck,
  Sparkles,
  PieChart as PieIcon,
  BarChart2
} from 'lucide-react';
import { 
  PieChart, 
  Pie, 
  Cell, 
  BarChart, 
  Bar, 
  XAxis, 
  YAxis, 
  CartesianGrid, 
  Tooltip, 
  ResponsiveContainer,
  Legend 
} from 'recharts';
import { analyticsApi, predictApi } from '../services/api';
import { useAuth } from '../context/AuthContext';
import VitalsChart from '../components/VitalsChart';

const Dashboard = () => {
  const { user, showToast } = useAuth();
  const [data, setData] = useState(null);
  const [history, setHistory] = useState([]);
  const [loading, setLoading] = useState(true);
  const [completedReminders, setCompletedReminders] = useState({});

  useEffect(() => {
    const fetchDashboardData = async () => {
      setLoading(true);
      try {
        const [dashData, histData] = await Promise.all([
          analyticsApi.getDashboard(),
          predictApi.getHistory()
        ]);
        setData(dashData);
        setHistory(histData || []);
      } catch (err) {
        showToast('Failed to load dashboard metrics: ' + err.message, 'error');
      } finally {
        setLoading(false);
      }
    };

    fetchDashboardData();
  }, []);

  const toggleReminder = (id) => {
    setCompletedReminders(prev => ({
      ...prev,
      [id]: !prev[id]
    }));
  };

  if (loading) {
    return (
      <div className="min-h-[60vh] flex flex-col items-center justify-center space-y-3">
        <Activity className="w-8 h-8 text-cyan-400 animate-spin" />
        <span className="text-xs text-slate-400 font-medium">Loading clinical analytics and vitals...</span>
      </div>
    );
  }

  const latestBp = data?.vitals?.latest_bp;
  const latestGlu = data?.vitals?.latest_glucose;
  const reminders = data?.reminders || [];
  const urgencyDist = data?.urgency_distribution || [];
  const symptomFreq = data?.symptom_frequency || [];

  return (
    <div className="max-w-7xl mx-auto space-y-8 py-4">
      
      {/* Welcome Header */}
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4 border-b border-slate-800 pb-5">
        <div className="space-y-1">
          <div className="flex items-center space-x-2 text-cyan-400 text-xs font-bold uppercase tracking-wider">
            <Activity className="w-4 h-4" />
            <span>Patient Health Intelligence Hub</span>
          </div>
          <h1 className="text-2xl sm:text-3xl font-extrabold text-white tracking-tight">
            Welcome back, {user?.full_name}
          </h1>
          <p className="text-xs text-slate-400">
            Real-time longitudinal overview of your electronic health records, vitals telemetry, and AI assessments.
          </p>
        </div>

        <Link
          to="/checker"
          className="flex items-center space-x-2 px-5 py-2.5 rounded-xl bg-gradient-to-r from-cyan-500 to-teal-400 hover:from-cyan-400 hover:to-teal-300 text-slate-950 font-bold text-xs shadow-lg shadow-cyan-500/20 transition transform hover:-translate-y-0.5 active:translate-y-0 self-start sm:self-auto"
        >
          <Stethoscope className="w-4 h-4" />
          <span>New Symptom Check</span>
        </Link>
      </div>

      {/* Overview Metric Snapshot Cards */}
      <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-4">
        
        {/* Latest Prediction */}
        <div className="glass-card p-5 space-y-2 border-slate-800">
          <div className="flex items-center justify-between text-xs text-slate-400 font-medium">
            <span>Latest Health Condition</span>
            <Stethoscope className="w-4 h-4 text-cyan-400" />
          </div>
          <div className="text-lg font-bold text-white truncate">
            {data?.summary?.latest_assessment || 'No checks yet'}
          </div>
          <div className="flex items-center justify-between text-[11px] pt-1">
            <span className="text-slate-400">{data?.summary?.latest_check_date || 'N/A'}</span>
            {data?.summary?.latest_urgency && data.summary.latest_urgency !== 'None' && (
              <span className="px-2 py-0.5 rounded-full bg-cyan-500/20 text-cyan-300 border border-cyan-500/30 text-[10px] font-bold uppercase">
                {data.summary.latest_urgency} Urgency
              </span>
            )}
          </div>
        </div>

        {/* Latest BP */}
        <div className="glass-card p-5 space-y-2 border-slate-800">
          <div className="flex items-center justify-between text-xs text-slate-400 font-medium">
            <span>Recent Blood Pressure</span>
            <Heart className="w-4 h-4 text-rose-400" />
          </div>
          <div className="text-xl font-extrabold text-white font-mono">
            {latestBp ? `${latestBp.systolic}/${latestBp.diastolic}` : '120/80'} <span className="text-xs font-normal text-slate-400">mmHg</span>
          </div>
          <div className="text-[11px] text-slate-400 flex items-center justify-between pt-1">
            <span>{latestBp?.date || 'Estimated'}</span>
            <span className={`px-2 py-0.5 rounded-full text-[10px] font-bold ${
              latestBp && latestBp.systolic >= 140 ? 'bg-amber-500/20 text-amber-300' : 'bg-emerald-500/20 text-emerald-300'
            }`}>
              {latestBp && latestBp.systolic >= 140 ? 'Elevated' : 'Optimal'}
            </span>
          </div>
        </div>

        {/* Fasting Glucose */}
        <div className="glass-card p-5 space-y-2 border-slate-800">
          <div className="flex items-center justify-between text-xs text-slate-400 font-medium">
            <span>Fasting Glucose</span>
            <Droplet className="w-4 h-4 text-teal-400" />
          </div>
          <div className="text-xl font-extrabold text-white font-mono">
            {latestGlu ? latestGlu.fasting : '92.0'} <span className="text-xs font-normal text-slate-400">mg/dL</span>
          </div>
          <div className="text-[11px] text-slate-400 flex items-center justify-between pt-1">
            <span>{latestGlu?.date || 'Estimated'}</span>
            <span className="px-2 py-0.5 rounded-full bg-teal-500/20 text-teal-300 text-[10px] font-bold">
              Controlled
            </span>
          </div>
        </div>

        {/* Total EHR Records */}
        <div className="glass-card p-5 space-y-2 border-slate-800">
          <div className="flex items-center justify-between text-xs text-slate-400 font-medium">
            <span>Total EHR Records</span>
            <Clock className="w-4 h-4 text-indigo-400" />
          </div>
          <div className="text-xl font-extrabold text-white font-mono">
            {data?.summary?.total_records || 0} <span className="text-xs font-normal text-slate-400">Entries</span>
          </div>
          <div className="text-[11px] text-slate-400 flex items-center justify-between pt-1">
            <span>{data?.summary?.total_assessments || 0} Assessments</span>
            <Link to="/timeline" className="text-cyan-400 hover:underline">View Timeline</Link>
          </div>
        </div>

      </div>

      {/* Main Charts Row: Vitals Trend Series & Medication Reminders */}
      <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
        
        {/* Vitals Telemetry Chart (2 Columns) */}
        <div className="lg:col-span-2">
          <VitalsChart vitalsData={data?.vitals} />
        </div>

        {/* Reminders & Medication Schedule (1 Column) */}
        <div className="glass-card p-6 space-y-4 flex flex-col justify-between">
          <div className="space-y-4">
            <div className="flex items-center justify-between border-b border-slate-800 pb-3">
              <div className="flex items-center space-x-2">
                <Bell className="w-4 h-4 text-cyan-400" />
                <h3 className="text-base font-bold text-white">Daily Medication & Follow-ups</h3>
              </div>
              <span className="text-xs bg-slate-800 px-2 py-0.5 rounded text-slate-300">
                {reminders.length} Active
              </span>
            </div>

            <div className="space-y-2.5 max-h-72 overflow-y-auto custom-scrollbar pr-1">
              {reminders.length === 0 ? (
                <div className="text-xs text-slate-500 py-8 text-center italic">
                  No active medication reminders configured. Add current medications in your Health Profile.
                </div>
              ) : (
                reminders.map((rem) => {
                  const isDone = completedReminders[rem.id];
                  return (
                    <div
                      key={rem.id}
                      onClick={() => toggleReminder(rem.id)}
                      className={`p-3 rounded-xl border transition cursor-pointer flex items-start space-x-3 ${
                        isDone
                          ? 'bg-slate-950/40 border-slate-800/80 opacity-60'
                          : rem.type === 'clinical_alert'
                          ? 'bg-rose-950/20 border-rose-500/40'
                          : 'bg-slate-900/80 border-slate-800 hover:border-slate-700'
                      }`}
                    >
                      <div className="mt-0.5">
                        <CheckCircle2 className={`w-4 h-4 ${isDone ? 'text-emerald-400' : 'text-slate-600'}`} />
                      </div>
                      <div className="space-y-0.5">
                        <h4 className={`text-xs font-bold ${isDone ? 'line-through text-slate-400' : 'text-white'}`}>
                          {rem.title}
                        </h4>
                        <p className="text-[11px] text-slate-400">{rem.description}</p>
                        <span className="text-[10px] text-cyan-300 font-semibold">{rem.due}</span>
                      </div>
                    </div>
                  );
                })
              )}
            </div>
          </div>

          <Link
            to="/profile"
            className="w-full text-center py-2 text-xs font-semibold text-cyan-400 hover:text-cyan-300 border border-slate-800 hover:border-slate-700 rounded-xl transition"
          >
            Manage Medications in Profile
          </Link>
        </div>

      </div>

      {/* Second Row: Symptom Frequencies Bar Chart & Urgency Distribution Pie Chart */}
      <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
        
        {/* Symptom Frequency */}
        <div className="glass-card p-6 space-y-4">
          <div className="flex items-center justify-between border-b border-slate-800 pb-3">
            <div className="flex items-center space-x-2">
              <BarChart2 className="w-4 h-4 text-cyan-400" />
              <h3 className="text-base font-bold text-white">Top Logged Symptoms</h3>
            </div>
            <span className="text-xs text-slate-400">Past Assessment Frequency</span>
          </div>

          <div className="h-60 w-full">
            {symptomFreq.length === 0 ? (
              <div className="h-full flex items-center justify-center text-xs text-slate-500">
                Run symptom checks to build your symptom frequency history.
              </div>
            ) : (
              <ResponsiveContainer width="100%" height="100%">
                <BarChart data={symptomFreq} layout="vertical" margin={{ top: 5, right: 20, left: 40, bottom: 5 }}>
                  <CartesianGrid strokeDasharray="3 3" stroke="#1E293B" />
                  <XAxis type="number" stroke="#64748B" tick={{ fontSize: 10 }} />
                  <YAxis type="category" dataKey="name" stroke="#94A3B8" tick={{ fontSize: 10 }} width={90} />
                  <Tooltip
                    contentStyle={{ backgroundColor: '#0F172A', borderColor: '#334155', borderRadius: '12px', fontSize: '11px' }}
                  />
                  <Bar dataKey="count" name="Frequency" fill="#06B6D4" radius={[0, 4, 4, 0]} />
                </BarChart>
              </ResponsiveContainer>
            )}
          </div>
        </div>

        {/* Urgency Rating Distribution */}
        <div className="glass-card p-6 space-y-4">
          <div className="flex items-center justify-between border-b border-slate-800 pb-3">
            <div className="flex items-center space-x-2">
              <PieIcon className="w-4 h-4 text-teal-400" />
              <h3 className="text-base font-bold text-white">Triage Urgency Breakdown</h3>
            </div>
            <span className="text-xs text-slate-400">All Assessments</span>
          </div>

          <div className="h-60 w-full flex items-center justify-center">
            {urgencyDist.every(u => u.value === 0) ? (
              <div className="text-xs text-slate-500">No predictions evaluated yet.</div>
            ) : (
              <ResponsiveContainer width="100%" height="100%">
                <PieChart>
                  <Pie
                    data={urgencyDist.filter(u => u.value > 0)}
                    cx="50%"
                    cy="50%"
                    innerRadius={50}
                    outerRadius={80}
                    paddingAngle={5}
                    dataKey="value"
                  >
                    {urgencyDist.map((entry, index) => (
                      <Cell key={`cell-${index}`} fill={entry.color} />
                    ))}
                  </Pie>
                  <Tooltip
                    contentStyle={{ backgroundColor: '#0F172A', borderColor: '#334155', borderRadius: '12px', fontSize: '11px' }}
                  />
                  <Legend wrapperStyle={{ fontSize: '11px' }} />
                </PieChart>
              </ResponsiveContainer>
            )}
          </div>
        </div>

      </div>

      {/* Recent Predictions History Table */}
      <div className="glass-card p-6 space-y-4">
        <div className="flex items-center justify-between border-b border-slate-800 pb-3">
          <div className="flex items-center space-x-2">
            <Clock className="w-4 h-4 text-cyan-400" />
            <h3 className="text-base font-bold text-white">Recent Assessment History</h3>
          </div>
          <span className="text-xs text-slate-400">{history.length} Total</span>
        </div>

        <div className="overflow-x-auto">
          {history.length === 0 ? (
            <div className="text-xs text-slate-500 py-6 text-center">
              No historical checks recorded yet. Use the Symptom Checker to generate your first assessment.
            </div>
          ) : (
            <table className="w-full text-left text-xs">
              <thead className="text-[10px] uppercase text-slate-400 border-b border-slate-800">
                <tr>
                  <th className="py-2.5 px-3">Date</th>
                  <th className="py-2.5 px-3">Primary Condition</th>
                  <th className="py-2.5 px-3">Urgency</th>
                  <th className="py-2.5 px-3">Confidence</th>
                  <th className="py-2.5 px-3">Symptoms</th>
                  <th className="py-2.5 px-3 text-right">Action</th>
                </tr>
              </thead>
              <tbody className="divide-y divide-slate-800/60">
                {history.slice(0, 5).map((h) => (
                  <tr key={h.id} className="hover:bg-slate-900/50 transition">
                    <td className="py-3 px-3 text-slate-400 font-mono text-[11px]">
                      {new Date(h.created_at).toLocaleDateString('en-US', { month: 'short', day: 'numeric', year: 'numeric' })}
                    </td>
                    <td className="py-3 px-3 font-semibold text-white">{h.top_condition}</td>
                    <td className="py-3 px-3">
                      <span className={`px-2 py-0.5 rounded-full text-[10px] font-bold uppercase ${
                        h.urgency === 'Emergency' ? 'bg-rose-500/20 text-rose-300' :
                        h.urgency === 'High' ? 'bg-amber-500/20 text-amber-300' :
                        h.urgency === 'Medium' ? 'bg-yellow-500/20 text-yellow-300' :
                        'bg-emerald-500/20 text-emerald-300'
                      }`}>
                        {h.urgency}
                      </span>
                    </td>
                    <td className="py-3 px-3 font-mono font-bold text-cyan-300">{h.top_confidence}%</td>
                    <td className="py-3 px-3 text-slate-400 max-w-[200px] truncate">
                      {h.symptoms_selected.map(s => s.replace('_', ' ')).join(', ')}
                    </td>
                    <td className="py-3 px-3 text-right">
                      <button
                        onClick={() => {
                          sessionStorage.setItem('symptomsense_latest_result', JSON.stringify({
                            is_emergency: h.is_emergency,
                            emergency_trigger: h.emergency_trigger,
                            top_condition: h.top_condition,
                            top_condition_icd10: h.top_condition_icd10,
                            top_confidence: h.top_confidence,
                            urgency: h.urgency,
                            specialist: h.specialist,
                            predictions: h.all_predictions,
                            explainability: h.explainability,
                            recommended_actions: h.recommended_actions,
                            home_care: h.home_care,
                            red_flags: h.red_flags,
                            patient_history_summary: { age: 35 }
                          }));
                          window.location.href = '/results';
                        }}
                        className="text-cyan-400 hover:text-cyan-300 font-semibold"
                      >
                        Inspect
                      </button>
                    </td>
                  </tr>
                ))}
              </tbody>
            </table>
          )}
        </div>
      </div>

    </div>
  );
};

export default Dashboard;
