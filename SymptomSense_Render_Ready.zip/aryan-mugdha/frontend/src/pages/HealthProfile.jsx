import React, { useState, useEffect } from 'react';
import { 
  User, 
  Heart, 
  Activity, 
  Pill, 
  ShieldAlert, 
  Save, 
  Plus, 
  Trash2, 
  Phone, 
  Calendar, 
  Sparkles,
  CheckCircle2,
  AlertCircle
} from 'lucide-react';
import { profileApi } from '../services/api';
import { useAuth } from '../context/AuthContext';

const COMMON_CHRONIC = [
  'Hypertension',
  'Type 2 Diabetes Mellitus',
  'Bronchial Asthma',
  'Coronary Artery Disease',
  'Hyperlipidemia (High Cholesterol)',
  'GERD (Acid Reflux)',
  'Hypothyroidism',
  'Osteoarthritis',
  'Rheumatoid Arthritis',
  'Migraine'
];

const COMMON_ALLERGIES = [
  'Penicillin',
  'Sulfa Drugs',
  'Aspirin / NSAIDs',
  'Peanuts / Tree Nuts',
  'Shellfish',
  'Latex',
  'Pollen / Ragweed',
  'Dust Mites',
  'Pet Dander'
];

const HealthProfile = () => {
  const { user, showToast } = useAuth();
  const [profile, setProfile] = useState({
    age: 30,
    gender: 'male',
    blood_group: 'O+',
    height_cm: 172,
    weight_kg: 70,
    bmi: 23.66,
    smoking_status: 'never',
    alcohol_use: 'never',
    physical_activity: 'moderate',
    allergies: [],
    chronic_conditions: [],
    current_medications: [],
    past_diagnoses: [],
    family_history: [],
    emergency_contact_name: '',
    emergency_contact_phone: '',
    emergency_contact_relation: ''
  });

  const [loading, setLoading] = useState(true);
  const [saving, setSaving] = useState(false);

  // New tag inputs
  const [allergyInput, setAllergyInput] = useState('');
  const [chronicInput, setChronicInput] = useState('');
  const [familyInput, setFamilyInput] = useState('');
  const [diagnosisInput, setDiagnosisInput] = useState('');

  // New medication form
  const [newMed, setNewMed] = useState({ name: '', dose: '', frequency: '', purpose: '' });

  useEffect(() => {
    const fetchProfile = async () => {
      try {
        const data = await profileApi.getProfile();
        setProfile(data);
      } catch (err) {
        showToast('Failed to load profile: ' + err.message, 'error');
      } finally {
        setLoading(false);
      }
    };
    fetchProfile();
  }, []);

  const calculateBMI = (height, weight) => {
    if (height > 0 && weight > 0) {
      const hM = height / 100;
      return Math.round((weight / (hM * hM)) * 100) / 100;
    }
    return 22.0;
  };

  const handleMetricChange = (field, val) => {
    const num = Number(val);
    const updated = { ...profile, [field]: num };
    if (field === 'height_cm' || field === 'weight_kg') {
      const h = field === 'height_cm' ? num : profile.height_cm;
      const w = field === 'weight_kg' ? num : profile.weight_kg;
      updated.bmi = calculateBMI(h, w);
    }
    setProfile(updated);
  };

  const addTag = (field, value, setter) => {
    if (!value.trim()) return;
    if (!profile[field].includes(value.trim())) {
      setProfile({
        ...profile,
        [field]: [...profile[field], value.trim()]
      });
    }
    setter('');
  };

  const removeTag = (field, valToRemove) => {
    setProfile({
      ...profile,
      [field]: profile[field].filter(item => item !== valToRemove)
    });
  };

  const addMedication = () => {
    if (!newMed.name.trim()) return;
    setProfile({
      ...profile,
      current_medications: [...profile.current_medications, { ...newMed }]
    });
    setNewMed({ name: '', dose: '', frequency: '', purpose: '' });
  };

  const removeMedication = (idx) => {
    setProfile({
      ...profile,
      current_medications: profile.current_medications.filter((_, i) => i !== idx)
    });
  };

  const handleSubmit = async (e) => {
    e.preventDefault();
    setSaving(true);
    try {
      const updated = await profileApi.updateProfile(profile);
      setProfile(updated);
      showToast('Health Profile successfully updated and encrypted!', 'success');
    } catch (err) {
      showToast('Failed to save profile: ' + err.message, 'error');
    } finally {
      setSaving(false);
    }
  };

  const getBMICategory = (bmi) => {
    if (bmi < 18.5) return { label: 'Underweight', color: 'text-amber-400' };
    if (bmi < 25) return { label: 'Normal Weight (Optimal)', color: 'text-emerald-400' };
    if (bmi < 30) return { label: 'Overweight', color: 'text-yellow-400' };
    return { label: 'Obese (Elevated Cardiometabolic Risk)', color: 'text-rose-400' };
  };

  if (loading) {
    return (
      <div className="min-h-[50vh] flex flex-col items-center justify-center space-y-3">
        <Activity className="w-8 h-8 text-cyan-400 animate-spin" />
        <span className="text-xs text-slate-400">Loading private EHR profile...</span>
      </div>
    );
  }

  const bmiCat = getBMICategory(profile.bmi);

  return (
    <div className="max-w-4xl mx-auto space-y-8 py-4">
      
      {/* Page Header */}
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4 border-b border-slate-800 pb-4">
        <div className="space-y-1">
          <div className="flex items-center space-x-2 text-cyan-400 text-xs font-bold uppercase tracking-wider">
            <User className="w-4 h-4" />
            <span>Electronic Health Record</span>
          </div>
          <h1 className="text-2xl sm:text-3xl font-extrabold text-white tracking-tight">
            Patient Health Profile & Baseline Data
          </h1>
          <p className="text-xs text-slate-400">
            This private data is securely encrypted and used to calibrate the SymptomSense ML diagnostic engine.
          </p>
        </div>

        <button
          onClick={handleSubmit}
          disabled={saving}
          className="flex items-center space-x-2 px-6 py-2.5 bg-gradient-to-r from-cyan-500 to-teal-400 hover:from-cyan-400 hover:to-teal-300 text-slate-950 font-bold text-xs rounded-xl shadow-lg shadow-cyan-500/20 transition self-start sm:self-auto disabled:opacity-50"
        >
          <Save className="w-4 h-4" />
          <span>{saving ? 'Saving...' : 'Save Health Profile'}</span>
        </button>
      </div>

      <form onSubmit={handleSubmit} className="space-y-8">
        
        {/* 1. Demographics & Body Metrics */}
        <div className="glass-card p-6 sm:p-8 space-y-6">
          <div className="flex items-center space-x-2 border-b border-slate-800 pb-3">
            <Activity className="w-4 h-4 text-cyan-400" />
            <h2 className="text-base font-bold text-white">Demographics & Anthropometrics</h2>
          </div>

          <div className="grid grid-cols-1 sm:grid-cols-3 gap-4">
            <div>
              <label className="block text-xs font-semibold text-slate-300 mb-1">Age (Years)</label>
              <input
                type="number"
                min="1"
                max="120"
                value={profile.age}
                onChange={(e) => handleMetricChange('age', e.target.value)}
                className="w-full bg-slate-950 border border-slate-800 rounded-xl px-3 py-2.5 text-xs text-white focus:outline-none focus:border-cyan-500"
              />
            </div>

            <div>
              <label className="block text-xs font-semibold text-slate-300 mb-1">Biological Gender</label>
              <select
                value={profile.gender}
                onChange={(e) => setProfile({ ...profile, gender: e.target.value })}
                className="w-full bg-slate-950 border border-slate-800 rounded-xl px-3 py-2.5 text-xs text-white focus:outline-none focus:border-cyan-500"
              >
                <option value="male">Male</option>
                <option value="female">Female</option>
                <option value="other">Other</option>
              </select>
            </div>

            <div>
              <label className="block text-xs font-semibold text-slate-300 mb-1">Blood Group</label>
              <select
                value={profile.blood_group}
                onChange={(e) => setProfile({ ...profile, blood_group: e.target.value })}
                className="w-full bg-slate-950 border border-slate-800 rounded-xl px-3 py-2.5 text-xs text-white focus:outline-none focus:border-cyan-500"
              >
                {['A+', 'A-', 'B+', 'B-', 'AB+', 'AB-', 'O+', 'O-'].map(bg => (
                  <option key={bg} value={bg}>{bg}</option>
                ))}
              </select>
            </div>
          </div>

          <div className="grid grid-cols-1 sm:grid-cols-3 gap-4 pt-2">
            <div>
              <label className="block text-xs font-semibold text-slate-300 mb-1">Height (cm)</label>
              <input
                type="number"
                step="0.5"
                value={profile.height_cm}
                onChange={(e) => handleMetricChange('height_cm', e.target.value)}
                className="w-full bg-slate-950 border border-slate-800 rounded-xl px-3 py-2.5 text-xs text-white focus:outline-none focus:border-cyan-500"
              />
            </div>

            <div>
              <label className="block text-xs font-semibold text-slate-300 mb-1">Weight (kg)</label>
              <input
                type="number"
                step="0.5"
                value={profile.weight_kg}
                onChange={(e) => handleMetricChange('weight_kg', e.target.value)}
                className="w-full bg-slate-950 border border-slate-800 rounded-xl px-3 py-2.5 text-xs text-white focus:outline-none focus:border-cyan-500"
              />
            </div>

            {/* Computed BMI Display */}
            <div className="bg-slate-950/80 p-3 rounded-xl border border-slate-800 flex flex-col justify-center space-y-1">
              <div className="flex items-center justify-between text-xs">
                <span className="text-slate-400">Body Mass Index (BMI):</span>
                <span className="font-mono font-bold text-white text-sm">{profile.bmi}</span>
              </div>
              <span className={`text-[10px] font-semibold ${bmiCat.color}`}>{bmiCat.label}</span>
            </div>
          </div>
        </div>

        {/* 2. Lifestyle Factors */}
        <div className="glass-card p-6 sm:p-8 space-y-4">
          <div className="flex items-center space-x-2 border-b border-slate-800 pb-3">
            <Heart className="w-4 h-4 text-teal-400" />
            <h2 className="text-base font-bold text-white">Lifestyle & Habits</h2>
          </div>

          <div className="grid grid-cols-1 sm:grid-cols-3 gap-4">
            <div>
              <label className="block text-xs font-semibold text-slate-300 mb-1">Smoking History</label>
              <select
                value={profile.smoking_status}
                onChange={(e) => setProfile({ ...profile, smoking_status: e.target.value })}
                className="w-full bg-slate-950 border border-slate-800 rounded-xl px-3 py-2.5 text-xs text-white focus:outline-none focus:border-cyan-500"
              >
                <option value="never">Never Smoked</option>
                <option value="former">Former Smoker</option>
                <option value="current">Current Smoker</option>
              </select>
            </div>

            <div>
              <label className="block text-xs font-semibold text-slate-300 mb-1">Alcohol Consumption</label>
              <select
                value={profile.alcohol_use}
                onChange={(e) => setProfile({ ...profile, alcohol_use: e.target.value })}
                className="w-full bg-slate-950 border border-slate-800 rounded-xl px-3 py-2.5 text-xs text-white focus:outline-none focus:border-cyan-500"
              >
                <option value="never">Never</option>
                <option value="occasional">Occasional (Social)</option>
                <option value="frequent">Frequent / Regular</option>
              </select>
            </div>

            <div>
              <label className="block text-xs font-semibold text-slate-300 mb-1">Physical Activity</label>
              <select
                value={profile.physical_activity}
                onChange={(e) => setProfile({ ...profile, physical_activity: e.target.value })}
                className="w-full bg-slate-950 border border-slate-800 rounded-xl px-3 py-2.5 text-xs text-white focus:outline-none focus:border-cyan-500"
              >
                <option value="sedentary">Sedentary (Little to no exercise)</option>
                <option value="moderate">Moderate (1-3 days/week)</option>
                <option value="active">Active (4+ days/week)</option>
              </select>
            </div>
          </div>
        </div>

        {/* 3. Chronic Conditions */}
        <div className="glass-card p-6 sm:p-8 space-y-4">
          <div className="flex items-center justify-between border-b border-slate-800 pb-3">
            <div className="flex items-center space-x-2">
              <Activity className="w-4 h-4 text-amber-400" />
              <h2 className="text-base font-bold text-white">Chronic Health Conditions</h2>
            </div>
            <span className="text-xs text-slate-400">{profile.chronic_conditions.length} Logged</span>
          </div>

          {/* Quick presets */}
          <div className="space-y-1.5">
            <span className="text-[11px] text-slate-400 font-medium">Add Common Diagnoses:</span>
            <div className="flex flex-wrap gap-1.5">
              {COMMON_CHRONIC.map(item => (
                <button
                  type="button"
                  key={item}
                  onClick={() => addTag('chronic_conditions', item, () => {})}
                  className="text-[11px] px-2.5 py-1 rounded-lg bg-slate-900 hover:bg-slate-800 border border-slate-800 hover:border-amber-500/40 text-slate-300 transition flex items-center gap-1"
                >
                  <Plus className="w-3 h-3 text-amber-400" />
                  <span>{item}</span>
                </button>
              ))}
            </div>
          </div>

          {/* Input & Tags */}
          <div className="flex gap-2">
            <input
              type="text"
              value={chronicInput}
              onChange={(e) => setChronicInput(e.target.value)}
              placeholder="Type custom condition and press Add..."
              className="flex-1 bg-slate-950 border border-slate-800 rounded-xl px-3 py-2 text-xs text-white focus:outline-none focus:border-cyan-500"
            />
            <button
              type="button"
              onClick={() => addTag('chronic_conditions', chronicInput, setChronicInput)}
              className="px-4 py-2 bg-slate-800 hover:bg-slate-700 text-white rounded-xl text-xs font-bold transition"
            >
              Add
            </button>
          </div>

          <div className="flex flex-wrap gap-2 pt-1">
            {profile.chronic_conditions.map((item) => (
              <span
                key={item}
                className="text-xs px-3 py-1 bg-amber-500/15 border border-amber-500/30 text-amber-300 rounded-xl flex items-center space-x-2 font-medium"
              >
                <span>{item}</span>
                <button
                  type="button"
                  onClick={() => removeTag('chronic_conditions', item)}
                  className="text-amber-400 hover:text-white"
                >
                  &times;
                </button>
              </span>
            ))}
          </div>
        </div>

        {/* 4. Allergies */}
        <div className="glass-card p-6 sm:p-8 space-y-4">
          <div className="flex items-center justify-between border-b border-slate-800 pb-3">
            <div className="flex items-center space-x-2">
              <ShieldAlert className="w-4 h-4 text-rose-400" />
              <h2 className="text-base font-bold text-white">Allergies & Sensitivities</h2>
            </div>
            <span className="text-xs text-slate-400">{profile.allergies.length} Logged</span>
          </div>

          <div className="space-y-1.5">
            <span className="text-[11px] text-slate-400 font-medium">Add Common Allergies:</span>
            <div className="flex flex-wrap gap-1.5">
              {COMMON_ALLERGIES.map(item => (
                <button
                  type="button"
                  key={item}
                  onClick={() => addTag('allergies', item, () => {})}
                  className="text-[11px] px-2.5 py-1 rounded-lg bg-slate-900 hover:bg-slate-800 border border-slate-800 hover:border-rose-500/40 text-slate-300 transition flex items-center gap-1"
                >
                  <Plus className="w-3 h-3 text-rose-400" />
                  <span>{item}</span>
                </button>
              ))}
            </div>
          </div>

          <div className="flex gap-2">
            <input
              type="text"
              value={allergyInput}
              onChange={(e) => setAllergyInput(e.target.value)}
              placeholder="e.g. Latex, Penicillin, Peanuts..."
              className="flex-1 bg-slate-950 border border-slate-800 rounded-xl px-3 py-2 text-xs text-white focus:outline-none focus:border-cyan-500"
            />
            <button
              type="button"
              onClick={() => addTag('allergies', allergyInput, setAllergyInput)}
              className="px-4 py-2 bg-slate-800 hover:bg-slate-700 text-white rounded-xl text-xs font-bold transition"
            >
              Add
            </button>
          </div>

          <div className="flex flex-wrap gap-2 pt-1">
            {profile.allergies.map((item) => (
              <span
                key={item}
                className="text-xs px-3 py-1 bg-rose-500/15 border border-rose-500/30 text-rose-300 rounded-xl flex items-center space-x-2 font-medium"
              >
                <span>{item}</span>
                <button
                  type="button"
                  onClick={() => removeTag('allergies', item)}
                  className="text-rose-400 hover:text-white"
                >
                  &times;
                </button>
              </span>
            ))}
          </div>
        </div>

        {/* 5. Current Medications */}
        <div className="glass-card p-6 sm:p-8 space-y-4">
          <div className="flex items-center justify-between border-b border-slate-800 pb-3">
            <div className="flex items-center space-x-2">
              <Pill className="w-4 h-4 text-cyan-400" />
              <h2 className="text-base font-bold text-white">Current Active Medications</h2>
            </div>
            <span className="text-xs text-slate-400">{profile.current_medications.length} Prescribed</span>
          </div>

          <div className="grid grid-cols-1 sm:grid-cols-4 gap-2 bg-slate-950 p-3 rounded-xl border border-slate-800">
            <input
              type="text"
              placeholder="Medication name (e.g. Metformin)"
              value={newMed.name}
              onChange={(e) => setNewMed({ ...newMed, name: e.target.value })}
              className="bg-slate-900 border border-slate-800 rounded-lg px-2.5 py-2 text-xs text-white focus:outline-none focus:border-cyan-500"
            />
            <input
              type="text"
              placeholder="Dosage (e.g. 500mg)"
              value={newMed.dose}
              onChange={(e) => setNewMed({ ...newMed, dose: e.target.value })}
              className="bg-slate-900 border border-slate-800 rounded-lg px-2.5 py-2 text-xs text-white focus:outline-none focus:border-cyan-500"
            />
            <input
              type="text"
              placeholder="Frequency (e.g. Twice daily)"
              value={newMed.frequency}
              onChange={(e) => setNewMed({ ...newMed, frequency: e.target.value })}
              className="bg-slate-900 border border-slate-800 rounded-lg px-2.5 py-2 text-xs text-white focus:outline-none focus:border-cyan-500"
            />
            <button
              type="button"
              onClick={addMedication}
              className="px-3 py-2 bg-cyan-500 hover:bg-cyan-400 text-slate-950 font-bold rounded-lg text-xs transition"
            >
              Add Medication
            </button>
          </div>

          <div className="space-y-2">
            {profile.current_medications.map((med, idx) => (
              <div
                key={idx}
                className="p-3 bg-slate-900 border border-slate-800 rounded-xl flex items-center justify-between text-xs"
              >
                <div>
                  <span className="font-bold text-white">{med.name}</span>
                  <span className="text-slate-400 ml-2">({med.dose} • {med.frequency})</span>
                </div>
                <button
                  type="button"
                  onClick={() => removeMedication(idx)}
                  className="text-slate-400 hover:text-rose-400 p-1"
                >
                  <Trash2 className="w-4 h-4" />
                </button>
              </div>
            ))}
          </div>
        </div>

        {/* 6. Emergency Contact */}
        <div className="glass-card p-6 sm:p-8 space-y-4">
          <div className="flex items-center space-x-2 border-b border-slate-800 pb-3">
            <Phone className="w-4 h-4 text-emerald-400" />
            <h2 className="text-base font-bold text-white">Emergency Contact Information</h2>
          </div>

          <div className="grid grid-cols-1 sm:grid-cols-3 gap-4">
            <div>
              <label className="block text-xs font-semibold text-slate-300 mb-1">Contact Name</label>
              <input
                type="text"
                value={profile.emergency_contact_name || ''}
                onChange={(e) => setProfile({ ...profile, emergency_contact_name: e.target.value })}
                placeholder="Full Name"
                className="w-full bg-slate-950 border border-slate-800 rounded-xl px-3 py-2.5 text-xs text-white focus:outline-none focus:border-cyan-500"
              />
            </div>

            <div>
              <label className="block text-xs font-semibold text-slate-300 mb-1">Relationship</label>
              <input
                type="text"
                value={profile.emergency_contact_relation || ''}
                onChange={(e) => setProfile({ ...profile, emergency_contact_relation: e.target.value })}
                placeholder="e.g. Spouse, Parent, Sibling"
                className="w-full bg-slate-950 border border-slate-800 rounded-xl px-3 py-2.5 text-xs text-white focus:outline-none focus:border-cyan-500"
              />
            </div>

            <div>
              <label className="block text-xs font-semibold text-slate-300 mb-1">Phone Number</label>
              <input
                type="tel"
                value={profile.emergency_contact_phone || ''}
                onChange={(e) => setProfile({ ...profile, emergency_contact_phone: e.target.value })}
                placeholder="+1 (555) 000-0000"
                className="w-full bg-slate-950 border border-slate-800 rounded-xl px-3 py-2.5 text-xs text-white focus:outline-none focus:border-cyan-500"
              />
            </div>
          </div>
        </div>

        {/* Bottom Save Action */}
        <div className="flex justify-end pt-2">
          <button
            type="submit"
            disabled={saving}
            className="flex items-center space-x-2 px-8 py-3.5 bg-gradient-to-r from-cyan-500 to-teal-400 hover:from-cyan-400 hover:to-teal-300 text-slate-950 font-bold text-sm rounded-xl shadow-lg shadow-cyan-500/25 transition disabled:opacity-50"
          >
            <Save className="w-4 h-4" />
            <span>{saving ? 'Saving Profile...' : 'Save Health Profile'}</span>
          </button>
        </div>

      </form>
    </div>
  );
};

export default HealthProfile;
