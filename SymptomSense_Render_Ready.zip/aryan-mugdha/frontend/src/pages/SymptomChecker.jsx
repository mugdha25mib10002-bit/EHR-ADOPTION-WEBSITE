import React, { useState, useEffect } from 'react';
import { useNavigate } from 'react-router-dom';
import { 
  Stethoscope, 
  Search, 
  Sparkles, 
  AlertTriangle, 
  Check, 
  X, 
  BrainCircuit, 
  UserCheck, 
  Clock, 
  Activity, 
  Sliders, 
  HelpCircle,
  ShieldCheck,
  Flame,
  Info
} from 'lucide-react';
import { predictApi } from '../services/api';
import { useAuth } from '../context/AuthContext';
import EmergencyModal from '../components/EmergencyModal';

const QUICK_SYMPTOMS = [
  { id: 'fever', label: 'Fever / Chills' },
  { id: 'dry_cough', label: 'Dry Cough' },
  { id: 'shortness_of_breath', label: 'Shortness of Breath' },
  { id: 'chest_pain', label: 'Chest Pain' },
  { id: 'throbbing_headache', label: 'Throbbing Headache' },
  { id: 'heartburn', label: 'Heartburn / Reflux' },
  { id: 'dizziness', label: 'Dizziness' },
  { id: 'symmetric_joint_pain', label: 'Joint Pain' },
  { id: 'intense_skin_itching', label: 'Itchy Skin / Rash' },
  { id: 'burning_urination', label: 'Burning Urination' },
  { id: 'nausea', label: 'Nausea / Vomiting' },
  { id: 'fatigue', label: 'Severe Fatigue' }
];

const SymptomChecker = () => {
  const { user, isAuthenticated, showToast } = useAuth();
  const navigate = useNavigate();

  const [symptomsList, setSymptomsList] = useState([]);
  const [selectedSymptoms, setSelectedSymptoms] = useState([]);
  const [searchTerm, setSearchTerm] = useState('');
  const [activeCategory, setActiveCategory] = useState('All');
  
  // Free text & characteristics
  const [freeText, setFreeText] = useState('');
  const [severity, setSeverity] = useState(5);
  const [duration, setDuration] = useState('2-3 days');
  const [onset, setOnset] = useState('gradual');
  const [includeEHR, setIncludeEHR] = useState(true);
  
  // Loading & Emergency State
  const [loading, setLoading] = useState(false);
  const [emergencyAlert, setEmergencyAlert] = useState(null);
  const [showEmergencyModal, setShowEmergencyModal] = useState(false);

  useEffect(() => {
    const fetchSymptoms = async () => {
      try {
        const data = await predictApi.getSymptomsList();
        setSymptomsList(data.symptoms || []);
      } catch (err) {
        showToast('Failed to load symptom catalog: ' + err.message, 'error');
      }
    };
    fetchSymptoms();
  }, []);

  const categories = ['All', 'Respiratory & ENT', 'Cardiovascular', 'Gastrointestinal', 'Neurological', 'Dermatological', 'Musculoskeletal', 'Urological & Renal', 'Constitutional / Metabolic'];

  const filteredSymptoms = symptomsList.filter(s => {
    const matchesSearch = s.label.toLowerCase().includes(searchTerm.toLowerCase()) || s.id.toLowerCase().includes(searchTerm.toLowerCase());
    const matchesCategory = activeCategory === 'All' || s.category === activeCategory;
    return matchesSearch && matchesCategory;
  });

  const toggleSymptom = (symId) => {
    if (selectedSymptoms.includes(symId)) {
      setSelectedSymptoms(selectedSymptoms.filter(s => s !== symId));
    } else {
      setSelectedSymptoms([...selectedSymptoms, symId]);
      
      // Check emergency
      if (['chest_pain', 'chest_pressure_radiating', 'slurred_speech', 'facial_weakness', 'blood_in_sputum'].includes(symId)) {
        setEmergencyAlert(`Selected symptom (${symId.replace('_', ' ')}) is an emergency red flag.`);
        setShowEmergencyModal(true);
      }
    }
  };

  const removeSymptom = (symId) => {
    setSelectedSymptoms(selectedSymptoms.filter(s => s !== symId));
  };

  const handleFreeTextBlur = () => {
    if (!freeText.trim()) return;
    const lower = freeText.toLowerCase();
    if (lower.includes('chest pain') || lower.includes('cannot breathe') || lower.includes('stroke') || lower.includes('slurred')) {
      setEmergencyAlert('Your free-text description contains severe emergency red-flag keywords.');
      setShowEmergencyModal(true);
    }
  };

  const getSeverityLabel = (val) => {
    if (val <= 3) return { label: 'Mild (Noticeable but does not interrupt daily tasks)', color: 'text-emerald-400' };
    if (val <= 6) return { label: 'Moderate (Uncomfortable, impacts work/activities)', color: 'text-yellow-400' };
    if (val <= 8) return { label: 'Severe (Significant distress or severe pain)', color: 'text-amber-400' };
    return { label: 'Critical / Emergency Level (Requires immediate clinical assessment)', color: 'text-rose-400 font-bold animate-pulse' };
  };

  const handleSubmit = async (e) => {
    e.preventDefault();

    if (selectedSymptoms.length === 0 && !freeText.trim()) {
      showToast('Please select at least one symptom or describe your condition.', 'error');
      return;
    }

    setLoading(true);
    try {
      const payload = {
        symptoms: selectedSymptoms.length > 0 ? selectedSymptoms : ['fatigue'],
        description: freeText,
        severity: Number(severity),
        duration: duration,
        onset: onset,
        include_profile_history: Boolean(includeEHR && isAuthenticated)
      };

      const result = await predictApi.predictSymptoms(payload);
      
      // If result is an emergency, prompt modal
      if (result.is_emergency) {
        setEmergencyAlert(result.emergency_trigger);
        setShowEmergencyModal(true);
      }

      // Store in session storage for direct results view
      sessionStorage.setItem('symptomsense_latest_result', JSON.stringify(result));
      navigate('/results');
    } catch (err) {
      showToast('Prediction failed: ' + err.message, 'error');
    } finally {
      setLoading(false);
    }
  };

  return (
    <div className="max-w-4xl mx-auto space-y-8 py-4">
      
      {/* Page Title & Intro */}
      <div className="space-y-2">
        <div className="flex items-center space-x-2 text-cyan-400 text-xs font-bold uppercase tracking-wider">
          <Stethoscope className="w-4 h-4" />
          <span>Clinical Symptom Assessment</span>
        </div>
        <h1 className="text-3xl sm:text-4xl font-extrabold text-white tracking-tight">
          Symptom & EHR Diagnostic Engine
        </h1>
        <p className="text-xs sm:text-sm text-slate-400 leading-relaxed max-w-2xl">
          Select all current symptoms, specify timeline characteristics, and choose whether to integrate your private EHR history for risk-calibrated predictions.
        </p>
      </div>

      <form onSubmit={handleSubmit} className="space-y-8">
        
        {/* SECTION 1: Search & Multi-Select Symptoms */}
        <div className="glass-card p-6 sm:p-8 space-y-6">
          <div className="flex items-center justify-between border-b border-slate-800 pb-4">
            <div className="flex items-center space-x-2">
              <span className="w-6 h-6 rounded-full bg-cyan-500/20 text-cyan-300 font-bold text-xs flex items-center justify-center border border-cyan-500/40">
                1
              </span>
              <h2 className="text-base sm:text-lg font-bold text-white">Select Current Symptoms</h2>
            </div>
            <span className="text-xs font-semibold text-cyan-400 bg-cyan-500/10 px-3 py-1 rounded-full border border-cyan-500/20">
              {selectedSymptoms.length} Selected
            </span>
          </div>

          {/* Quick Select Chips */}
          <div className="space-y-2">
            <span className="text-xs font-semibold text-slate-400">Quick Common Symptoms:</span>
            <div className="flex flex-wrap gap-2">
              {QUICK_SYMPTOMS.map((q) => {
                const isSelected = selectedSymptoms.includes(q.id);
                return (
                  <button
                    type="button"
                    key={q.id}
                    onClick={() => toggleSymptom(q.id)}
                    className={`text-xs px-3 py-1.5 rounded-xl border transition flex items-center space-x-1.5 ${
                      isSelected
                        ? 'bg-cyan-500/25 border-cyan-500/60 text-cyan-200 font-semibold shadow-sm shadow-cyan-500/10'
                        : 'bg-slate-900 border-slate-800 text-slate-300 hover:border-slate-700 hover:text-white'
                    }`}
                  >
                    {isSelected && <Check className="w-3.5 h-3.5 text-cyan-400" />}
                    <span>{q.label}</span>
                  </button>
                );
              })}
            </div>
          </div>

          {/* Search Input & Category Filter */}
          <div className="space-y-3 pt-2">
            <div className="relative">
              <Search className="w-4 h-4 text-slate-400 absolute left-3.5 top-1/2 -translate-y-1/2" />
              <input
                type="text"
                value={searchTerm}
                onChange={(e) => setSearchTerm(e.target.value)}
                placeholder="Search across 240+ medical symptoms (e.g., chest pain, wheezing, jaundice, skin itching)..."
                className="w-full bg-slate-950 border border-slate-800 rounded-2xl pl-10 pr-4 py-3 text-xs sm:text-sm text-white placeholder-slate-500 focus:outline-none focus:border-cyan-500 transition"
              />
              {searchTerm && (
                <button
                  type="button"
                  onClick={() => setSearchTerm('')}
                  className="absolute right-3.5 top-1/2 -translate-y-1/2 text-slate-500 hover:text-slate-300"
                >
                  <X className="w-4 h-4" />
                </button>
              )}
            </div>

            {/* Category Filter Pills */}
            <div className="flex items-center space-x-1.5 overflow-x-auto custom-scrollbar pb-1">
              {categories.map((cat) => (
                <button
                  type="button"
                  key={cat}
                  onClick={() => setActiveCategory(cat)}
                  className={`text-[11px] px-3 py-1 rounded-full whitespace-nowrap transition font-medium ${
                    activeCategory === cat
                      ? 'bg-cyan-500 text-slate-950 font-bold shadow-md shadow-cyan-500/20'
                      : 'bg-slate-900/90 text-slate-400 hover:text-slate-200 border border-slate-800'
                  }`}
                >
                  {cat}
                </button>
              ))}
            </div>

            {/* Search Results Grid */}
            <div className="max-h-56 overflow-y-auto custom-scrollbar p-2 bg-slate-950/80 rounded-2xl border border-slate-800/80 grid grid-cols-1 sm:grid-cols-2 md:grid-cols-3 gap-1.5">
              {filteredSymptoms.length === 0 ? (
                <div className="col-span-full text-center py-6 text-xs text-slate-500">
                  No matching symptoms found for "{searchTerm}". Try describing it in the free-text box below.
                </div>
              ) : (
                filteredSymptoms.map((sym) => {
                  const isSelected = selectedSymptoms.includes(sym.id);
                  return (
                    <button
                      type="button"
                      key={sym.id}
                      onClick={() => toggleSymptom(sym.id)}
                      className={`text-left p-2 rounded-xl text-xs flex items-center justify-between transition ${
                        isSelected
                          ? 'bg-cyan-500/20 border border-cyan-500/50 text-cyan-200 font-semibold'
                          : 'bg-slate-900/60 hover:bg-slate-800/80 text-slate-300 border border-transparent'
                      }`}
                    >
                      <span className="truncate pr-2">{sym.label}</span>
                      {isSelected ? (
                        <Check className="w-3.5 h-3.5 text-cyan-400 flex-shrink-0" />
                      ) : (
                        <span className="text-[10px] text-slate-500 flex-shrink-0">{sym.category.split(' ')[0]}</span>
                      )}
                    </button>
                  );
                })
              )}
            </div>
          </div>

          {/* Selected Badges Box */}
          {selectedSymptoms.length > 0 && (
            <div className="p-3.5 bg-slate-900/80 border border-cyan-500/30 rounded-2xl space-y-2">
              <span className="text-xs font-semibold text-cyan-300">Selected Symptoms to Analyze:</span>
              <div className="flex flex-wrap gap-1.5">
                {selectedSymptoms.map((sId) => {
                  const symObj = symptomsList.find(s => s.id === sId);
                  const label = symObj ? symObj.label : sId.replace('_', ' ');
                  return (
                    <span
                      key={sId}
                      className="text-xs px-2.5 py-1 bg-cyan-500/20 border border-cyan-500/40 text-cyan-200 rounded-lg flex items-center space-x-1.5 font-medium"
                    >
                      <span>{label}</span>
                      <button
                        type="button"
                        onClick={() => removeSymptom(sId)}
                        className="text-cyan-400 hover:text-white"
                      >
                        <X className="w-3 h-3" />
                      </button>
                    </span>
                  );
                })}
              </div>
            </div>
          )}
        </div>

        {/* SECTION 2: Free-Text Narrative NLP Box */}
        <div className="glass-card p-6 sm:p-8 space-y-4">
          <div className="flex items-center justify-between border-b border-slate-800 pb-4">
            <div className="flex items-center space-x-2">
              <span className="w-6 h-6 rounded-full bg-teal-500/20 text-teal-300 font-bold text-xs flex items-center justify-center border border-teal-500/40">
                2
              </span>
              <h2 className="text-base sm:text-lg font-bold text-white">Free-Form Clinical Narrative (Optional)</h2>
            </div>
            <span className="text-[11px] text-teal-300 flex items-center gap-1">
              <Sparkles className="w-3.5 h-3.5" /> AI NLP Extractor
            </span>
          </div>

          <div>
            <label className="block text-xs font-semibold text-slate-300 mb-1.5">
              Describe in your own words how you are feeling:
            </label>
            <textarea
              rows={3}
              value={freeText}
              onChange={(e) => setFreeText(e.target.value)}
              onBlur={handleFreeTextBlur}
              placeholder="e.g. I woke up with a sharp burning pain in my upper abdomen that gets worse after spicy food, plus a sour taste and feeling bloated..."
              className="w-full bg-slate-950 border border-slate-800 rounded-2xl p-3.5 text-xs sm:text-sm text-slate-100 placeholder-slate-500 focus:outline-none focus:border-teal-500 transition custom-scrollbar leading-relaxed"
            />
          </div>
        </div>

        {/* SECTION 3: Severity, Duration & Onset Characteristics */}
        <div className="glass-card p-6 sm:p-8 space-y-6">
          <div className="flex items-center space-x-2 border-b border-slate-800 pb-4">
            <span className="w-6 h-6 rounded-full bg-emerald-500/20 text-emerald-300 font-bold text-xs flex items-center justify-center border border-emerald-500/40">
              3
            </span>
            <h2 className="text-base sm:text-lg font-bold text-white">Symptom Severity & Characteristics</h2>
          </div>

          {/* Severity Slider */}
          <div className="space-y-3">
            <div className="flex items-center justify-between">
              <label className="text-xs font-semibold text-slate-300 flex items-center gap-1.5">
                <Sliders className="w-3.5 h-3.5 text-cyan-400" />
                Pain & Discomfort Severity (1 to 10 scale):
              </label>
              <span className="text-sm font-bold font-display px-2.5 py-0.5 rounded-lg bg-slate-900 border border-slate-700 text-white">
                {severity} / 10
              </span>
            </div>

            <input
              type="range"
              min="1"
              max="10"
              value={severity}
              onChange={(e) => setSeverity(Number(e.target.value))}
              className="w-full accent-cyan-400 bg-slate-800 h-2 rounded-lg cursor-pointer"
            />

            <p className={`text-xs ${getSeverityLabel(severity).color}`}>
              {getSeverityLabel(severity).label}
            </p>
          </div>

          {/* Duration & Onset Grid */}
          <div className="grid grid-cols-1 sm:grid-cols-2 gap-4 pt-2">
            
            {/* Duration */}
            <div className="space-y-1.5">
              <label className="text-xs font-semibold text-slate-300 flex items-center gap-1">
                <Clock className="w-3.5 h-3.5 text-slate-400" />
                How long have symptoms lasted?
              </label>
              <select
                value={duration}
                onChange={(e) => setDuration(e.target.value)}
                className="w-full bg-slate-950 border border-slate-800 rounded-xl px-3 py-2.5 text-xs text-white focus:outline-none focus:border-cyan-500"
              >
                <option value="Less than 24 hours">Less than 24 hours</option>
                <option value="1-3 days">1 to 3 days</option>
                <option value="4-7 days">4 to 7 days (1 week)</option>
                <option value="1-2 weeks">1 to 2 weeks</option>
                <option value="Over 1 month">Over 1 month (Chronic)</option>
              </select>
            </div>

            {/* Onset */}
            <div className="space-y-1.5">
              <label className="text-xs font-semibold text-slate-300 flex items-center gap-1">
                <Activity className="w-3.5 h-3.5 text-slate-400" />
                Onset Character:
              </label>
              <select
                value={onset}
                onChange={(e) => setOnset(e.target.value)}
                className="w-full bg-slate-950 border border-slate-800 rounded-xl px-3 py-2.5 text-xs text-white focus:outline-none focus:border-cyan-500"
              >
                <option value="gradual">Gradual / Developed over time</option>
                <option value="sudden">Sudden / Acute onset</option>
              </select>
            </div>

          </div>
        </div>

        {/* SECTION 4: EHR History Fusion Setting */}
        <div className="glass-card p-6 space-y-3 border-indigo-500/30">
          <div className="flex items-start justify-between gap-4">
            <div className="flex items-start space-x-3">
              <div className="p-2 bg-indigo-500/20 border border-indigo-500/40 rounded-xl text-indigo-400 mt-0.5">
                <UserCheck className="w-5 h-5" />
              </div>
              <div className="space-y-1">
                <h3 className="text-sm font-bold text-white flex items-center gap-2">
                  Incorporate Private Health Profile & Lab History
                  {isAuthenticated && (
                    <span className="text-[10px] px-2 py-0.5 rounded-full bg-emerald-500/15 border border-emerald-500/30 text-emerald-300 font-semibold">
                      Connected ({user?.full_name})
                    </span>
                  )}
                </h3>
                <p className="text-xs text-slate-400 leading-relaxed">
                  When enabled, the ML model calibrates prediction probabilities using your age, chronic illnesses (hypertension, diabetes, asthma), allergies, family history, and recent blood pressure / glucose observations.
                </p>
              </div>
            </div>

            <label className="relative inline-flex items-center cursor-pointer flex-shrink-0">
              <input
                type="checkbox"
                checked={includeEHR}
                onChange={(e) => setIncludeEHR(e.target.checked)}
                className="sr-only peer"
              />
              <div className="w-11 h-6 bg-slate-800 peer-focus:outline-none rounded-full peer peer-checked:after:translate-x-full peer-checked:after:border-white after:content-[''] after:absolute after:top-[2px] after:left-[2px] after:bg-white after:border-slate-300 after:border after:rounded-full after:h-5 after:w-5 after:transition-all peer-checked:bg-indigo-600"></div>
            </label>
          </div>
        </div>

        {/* Submission Button */}
        <div className="pt-2">
          <button
            type="submit"
            disabled={loading}
            className="w-full flex items-center justify-center space-x-2 py-4 px-6 rounded-2xl bg-gradient-to-r from-cyan-500 via-teal-400 to-emerald-400 hover:from-cyan-400 hover:to-emerald-300 text-slate-950 font-extrabold text-base shadow-xl shadow-cyan-500/20 transition transform hover:-translate-y-0.5 active:translate-y-0 disabled:opacity-50 cursor-pointer"
          >
            <BrainCircuit className={`w-5 h-5 ${loading ? 'animate-spin' : ''}`} />
            <span>{loading ? 'Evaluating Multi-Modal Medical Engine...' : 'Run SymptomSense Prediction'}</span>
          </button>
        </div>

      </form>

      {/* Emergency Modal Warning if triggered */}
      <EmergencyModal
        isOpen={showEmergencyModal}
        onClose={() => setShowEmergencyModal(false)}
        triggerReason={emergencyAlert}
      />

    </div>
  );
};

export default SymptomChecker;
