import React, { useState, useEffect } from 'react';
import { 
  Clock, 
  Plus, 
  Upload, 
  FileText, 
  Activity, 
  Heart, 
  Droplet, 
  Stethoscope, 
  Calendar, 
  Trash2, 
  Filter, 
  X,
  ExternalLink,
  ShieldCheck
} from 'lucide-react';
import { recordsApi, API_BASE } from '../services/api';
import { useAuth } from '../context/AuthContext';

const EHRTimeline = () => {
  const { user, showToast } = useAuth();
  const [records, setRecords] = useState([]);
  const [loading, setLoading] = useState(true);
  const [filterType, setFilterType] = useState('All');

  // Modals
  const [showAddModal, setShowAddModal] = useState(false);
  const [showUploadModal, setShowUploadModal] = useState(false);

  // New Record Form State
  const [newRec, setNewRec] = useState({
    title: '',
    record_type: 'lab_result',
    event_date: new Date().toISOString().split('T')[0],
    doctor_name: '',
    facility: '',
    notes: '',
    systolic_bp: '',
    diastolic_bp: '',
    heart_rate: '',
    blood_sugar_fasting: '',
    blood_sugar_postprandial: '',
    total_cholesterol: '',
    hdl_cholesterol: '',
    ldl_cholesterol: '',
    hemoglobin: '',
    spo2: '',
    body_temperature: ''
  });

  // Upload Form State
  const [uploadTitle, setUploadTitle] = useState('');
  const [uploadDoctor, setUploadDoctor] = useState('');
  const [uploadFacility, setUploadFacility] = useState('');
  const [uploadNotes, setUploadNotes] = useState('');
  const [uploadFile, setUploadFile] = useState(null);
  const [uploadDate, setUploadDate] = useState(new Date().toISOString().split('T')[0]);
  const [uploading, setUploading] = useState(false);

  useEffect(() => {
    fetchRecords();
  }, []);

  const fetchRecords = async () => {
    setLoading(true);
    try {
      const data = await recordsApi.getRecords();
      setRecords(data || []);
    } catch (err) {
      showToast('Failed to fetch records: ' + err.message, 'error');
    } finally {
      setLoading(false);
    }
  };

  const handleCreateRecord = async (e) => {
    e.preventDefault();
    if (!newRec.title.trim()) {
      showToast('Please provide a record title.', 'error');
      return;
    }

    try {
      const cleanPayload = {
        ...newRec,
        systolic_bp: newRec.systolic_bp ? Number(newRec.systolic_bp) : null,
        diastolic_bp: newRec.diastolic_bp ? Number(newRec.diastolic_bp) : null,
        heart_rate: newRec.heart_rate ? Number(newRec.heart_rate) : null,
        blood_sugar_fasting: newRec.blood_sugar_fasting ? Number(newRec.blood_sugar_fasting) : null,
        blood_sugar_postprandial: newRec.blood_sugar_postprandial ? Number(newRec.blood_sugar_postprandial) : null,
        total_cholesterol: newRec.total_cholesterol ? Number(newRec.total_cholesterol) : null,
        hdl_cholesterol: newRec.hdl_cholesterol ? Number(newRec.hdl_cholesterol) : null,
        ldl_cholesterol: newRec.ldl_cholesterol ? Number(newRec.ldl_cholesterol) : null,
        hemoglobin: newRec.hemoglobin ? Number(newRec.hemoglobin) : null,
        spo2: newRec.spo2 ? Number(newRec.spo2) : null,
        body_temperature: newRec.body_temperature ? Number(newRec.body_temperature) : null,
        event_date: newRec.event_date ? new Date(newRec.event_date).toISOString() : new Date().toISOString()
      };

      await recordsApi.createRecord(cleanPayload);
      showToast('Health record logged successfully!', 'success');
      setShowAddModal(false);
      fetchRecords();
    } catch (err) {
      showToast('Error creating record: ' + err.message, 'error');
    }
  };

  const handleUploadSubmit = async (e) => {
    e.preventDefault();
    if (!uploadFile || !uploadTitle.trim()) {
      showToast('Please enter a title and select a report file.', 'error');
      return;
    }

    setUploading(true);
    try {
      const formData = new FormData();
      formData.append('title', uploadTitle);
      formData.append('record_type', 'document_upload');
      formData.append('doctor_name', uploadDoctor);
      formData.append('facility', uploadFacility);
      formData.append('notes', uploadNotes);
      formData.append('event_date', new Date(uploadDate).toISOString());
      formData.append('file', uploadFile);

      await recordsApi.uploadReport(formData);
      showToast('Medical document uploaded & attached to EHR!', 'success');
      setShowUploadModal(false);
      setUploadFile(null);
      setUploadTitle('');
      fetchRecords();
    } catch (err) {
      showToast('Upload failed: ' + err.message, 'error');
    } finally {
      setUploading(false);
    }
  };

  const handleDeleteRecord = async (id) => {
    if (!confirm('Are you sure you want to permanently remove this EHR record?')) return;
    try {
      await recordsApi.deleteRecord(id);
      showToast('Record deleted.', 'info');
      setRecords(records.filter(r => r.id !== id));
    } catch (err) {
      showToast('Failed to delete: ' + err.message, 'error');
    }
  };

  const getRecordIcon = (type) => {
    switch (type) {
      case 'doctor_visit':
        return { icon: Stethoscope, color: 'text-indigo-400 bg-indigo-500/20 border-indigo-500/40' };
      case 'vital_sign':
        return { icon: Activity, color: 'text-cyan-400 bg-cyan-500/20 border-cyan-500/40' };
      case 'document_upload':
        return { icon: FileText, color: 'text-emerald-400 bg-emerald-500/20 border-emerald-500/40' };
      case 'lab_result':
      default:
        return { icon: Droplet, color: 'text-teal-400 bg-teal-500/20 border-teal-500/40' };
    }
  };

  const filteredRecords = records.filter(r => {
    if (filterType === 'All') return true;
    if (filterType === 'Lab Results') return r.record_type === 'lab_result';
    if (filterType === 'Doctor Visits') return r.record_type === 'doctor_visit';
    if (filterType === 'Vitals') return r.record_type === 'vital_sign';
    if (filterType === 'Documents') return r.record_type === 'document_upload';
    return true;
  });

  return (
    <div className="max-w-4xl mx-auto space-y-8 py-4">
      
      {/* Page Header */}
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4 border-b border-slate-800 pb-4">
        <div className="space-y-1">
          <div className="flex items-center space-x-2 text-cyan-400 text-xs font-bold uppercase tracking-wider">
            <Clock className="w-4 h-4" />
            <span>EHR Longitudinal Timeline</span>
          </div>
          <h1 className="text-2xl sm:text-3xl font-extrabold text-white tracking-tight">
            Past Medical Records & Encounters
          </h1>
          <p className="text-xs text-slate-400">
            Chronological audit trail of lab values, clinic visits, vitals checks, and attached diagnostic reports.
          </p>
        </div>

        <div className="flex items-center space-x-2.5 self-start sm:self-auto">
          <button
            onClick={() => setShowUploadModal(true)}
            className="flex items-center space-x-1.5 px-3.5 py-2 rounded-xl bg-slate-800 hover:bg-slate-700 text-slate-200 border border-slate-700 text-xs font-bold transition shadow-sm"
          >
            <Upload className="w-3.5 h-3.5 text-emerald-400" />
            <span>Upload Report</span>
          </button>
          <button
            onClick={() => setShowAddModal(true)}
            className="flex items-center space-x-1.5 px-4 py-2 rounded-xl bg-gradient-to-r from-cyan-500 to-teal-400 hover:from-cyan-400 hover:to-teal-300 text-slate-950 font-bold text-xs shadow-lg shadow-cyan-500/20 transition"
          >
            <Plus className="w-3.5 h-3.5" />
            <span>Add Lab Entry</span>
          </button>
        </div>
      </div>

      {/* Filter Tabs */}
      <div className="flex items-center space-x-2 overflow-x-auto custom-scrollbar pb-1">
        {['All', 'Lab Results', 'Doctor Visits', 'Vitals', 'Documents'].map(tab => (
          <button
            key={tab}
            onClick={() => setFilterType(tab)}
            className={`text-xs px-3.5 py-1.5 rounded-full font-semibold whitespace-nowrap transition ${
              filterType === tab
                ? 'bg-cyan-500 text-slate-950 font-bold shadow-md shadow-cyan-500/20'
                : 'bg-slate-900 text-slate-400 hover:text-white border border-slate-800'
            }`}
          >
            {tab}
          </button>
        ))}
      </div>

      {/* Vertical Chronological Timeline */}
      {loading ? (
        <div className="py-20 text-center text-xs text-slate-400">Loading timeline...</div>
      ) : filteredRecords.length === 0 ? (
        <div className="glass-card p-12 text-center space-y-3">
          <Clock className="w-10 h-10 text-slate-600 mx-auto" />
          <h3 className="text-base font-bold text-white">No EHR Records Found</h3>
          <p className="text-xs text-slate-400 max-w-sm mx-auto">
            Log your blood pressure, glucose, or cholesterol readings, or upload past medical reports to populate your timeline.
          </p>
        </div>
      ) : (
        <div className="relative border-l-2 border-slate-800 ml-4 sm:ml-6 space-y-8 pl-6 sm:pl-8">
          {filteredRecords.map((rec) => {
            const iconConfig = getRecordIcon(rec.record_type);
            const Icon = iconConfig.icon;
            const dateStr = new Date(rec.event_date).toLocaleDateString('en-US', {
              month: 'long',
              day: 'numeric',
              year: 'numeric'
            });

            return (
              <div key={rec.id} className="relative group">
                
                {/* Timeline Node Badge */}
                <div className={`absolute -left-[35px] sm:-left-[43px] top-1.5 w-8 h-8 rounded-full border flex items-center justify-center ${iconConfig.color}`}>
                  <Icon className="w-4 h-4" />
                </div>

                {/* Timeline Card Content */}
                <div className="glass-card glass-card-hover p-5 sm:p-6 space-y-3 border-slate-800/80">
                  <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-2 border-b border-slate-800 pb-3">
                    <div>
                      <div className="flex items-center space-x-2">
                        <span className="text-[10px] uppercase font-bold tracking-wider px-2 py-0.5 rounded-full bg-slate-800 text-slate-300">
                          {rec.record_type.replace('_', ' ')}
                        </span>
                        <span className="text-xs text-slate-400">{dateStr}</span>
                      </div>
                      <h3 className="text-base font-bold text-white mt-1">{rec.title}</h3>
                    </div>

                    <div className="flex items-center space-x-2 self-start sm:self-auto">
                      {rec.file_url && (
                        <a
                          href={`${API_BASE}${rec.file_url}`}
                          target="_blank"
                          rel="noopener noreferrer"
                          className="flex items-center space-x-1 px-2.5 py-1 bg-cyan-500/15 hover:bg-cyan-500/25 border border-cyan-500/40 text-cyan-300 text-[11px] rounded-lg font-semibold"
                        >
                          <FileText className="w-3 h-3" />
                          <span>View Attachment</span>
                          <ExternalLink className="w-2.5 h-2.5" />
                        </a>
                      )}
                      <button
                        onClick={() => handleDeleteRecord(rec.id)}
                        className="p-1.5 text-slate-500 hover:text-rose-400 rounded-lg hover:bg-slate-800 transition"
                        title="Delete record"
                      >
                        <Trash2 className="w-3.5 h-3.5" />
                      </button>
                    </div>
                  </div>

                  {/* Clinician / Facility */}
                  {(rec.doctor_name || rec.facility) && (
                    <div className="text-xs text-slate-400">
                      Encounter: <strong className="text-slate-300">{rec.doctor_name || 'Clinician'}</strong> {rec.facility && `at ${rec.facility}`}
                    </div>
                  )}

                  {/* Vitals Grid if present */}
                  {(rec.systolic_bp || rec.blood_sugar_fasting || rec.total_cholesterol || rec.hemoglobin || rec.spo2) && (
                    <div className="grid grid-cols-2 sm:grid-cols-4 gap-2 pt-1">
                      {rec.systolic_bp && rec.diastolic_bp && (
                        <div className="bg-slate-950/80 p-2.5 rounded-xl border border-slate-800/80">
                          <span className="text-[10px] text-slate-400 block">Blood Pressure</span>
                          <span className="text-xs font-mono font-bold text-cyan-300">{rec.systolic_bp}/{rec.diastolic_bp} mmHg</span>
                        </div>
                      )}
                      {rec.blood_sugar_fasting && (
                        <div className="bg-slate-950/80 p-2.5 rounded-xl border border-slate-800/80">
                          <span className="text-[10px] text-slate-400 block">Fasting Glucose</span>
                          <span className="text-xs font-mono font-bold text-teal-300">{rec.blood_sugar_fasting} mg/dL</span>
                        </div>
                      )}
                      {rec.total_cholesterol && (
                        <div className="bg-slate-950/80 p-2.5 rounded-xl border border-slate-800/80">
                          <span className="text-[10px] text-slate-400 block">Cholesterol</span>
                          <span className="text-xs font-mono font-bold text-indigo-300">{rec.total_cholesterol} mg/dL</span>
                        </div>
                      )}
                      {rec.spo2 && (
                        <div className="bg-slate-950/80 p-2.5 rounded-xl border border-slate-800/80">
                          <span className="text-[10px] text-slate-400 block">Oxygen SpO2</span>
                          <span className="text-xs font-mono font-bold text-emerald-300">{rec.spo2}%</span>
                        </div>
                      )}
                    </div>
                  )}

                  {/* Notes */}
                  {rec.notes && (
                    <p className="text-xs text-slate-400 italic bg-slate-950/40 p-2.5 rounded-xl border border-slate-900 leading-relaxed">
                      "{rec.notes}"
                    </p>
                  )}
                </div>
              </div>
            );
          })}
        </div>
      )}

      {/* Modal 1: Add New Record / Lab Entry */}
      {showAddModal && (
        <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-slate-950/85 backdrop-blur-md animate-fade-in no-print">
          <div className="bg-slate-900 border border-slate-700 rounded-3xl max-w-xl w-full p-6 sm:p-8 shadow-2xl text-white relative overflow-hidden max-h-[90vh] flex flex-col">
            <div className="flex items-center justify-between border-b border-slate-800 pb-3 mb-4">
              <h3 className="text-lg font-bold text-white flex items-center gap-2">
                <Plus className="w-5 h-5 text-cyan-400" /> Log Lab Values & Clinical Encounter
              </h3>
              <button onClick={() => setShowAddModal(false)} className="text-slate-400 hover:text-white">
                <X className="w-5 h-5" />
              </button>
            </div>

            <form onSubmit={handleCreateRecord} className="flex-1 overflow-y-auto custom-scrollbar space-y-4 pr-1">
              <div>
                <label className="block text-xs font-semibold text-slate-300 mb-1">Title / Encounter Reason *</label>
                <input
                  type="text"
                  required
                  value={newRec.title}
                  onChange={(e) => setNewRec({ ...newRec, title: e.target.value })}
                  placeholder="e.g. Comprehensive Metabolic Panel & BP Check"
                  className="w-full bg-slate-950 border border-slate-800 rounded-xl px-3 py-2 text-xs text-white focus:outline-none focus:border-cyan-500"
                />
              </div>

              <div className="grid grid-cols-2 gap-3">
                <div>
                  <label className="block text-xs font-semibold text-slate-300 mb-1">Record Type</label>
                  <select
                    value={newRec.record_type}
                    onChange={(e) => setNewRec({ ...newRec, record_type: e.target.value })}
                    className="w-full bg-slate-950 border border-slate-800 rounded-xl px-3 py-2 text-xs text-white focus:outline-none focus:border-cyan-500"
                  >
                    <option value="lab_result">Lab Result</option>
                    <option value="doctor_visit">Doctor Visit</option>
                    <option value="vital_sign">Vital Sign Reading</option>
                  </select>
                </div>
                <div>
                  <label className="block text-xs font-semibold text-slate-300 mb-1">Date</label>
                  <input
                    type="date"
                    value={newRec.event_date}
                    onChange={(e) => setNewRec({ ...newRec, event_date: e.target.value })}
                    className="w-full bg-slate-950 border border-slate-800 rounded-xl px-3 py-2 text-xs text-white focus:outline-none focus:border-cyan-500"
                  />
                </div>
              </div>

              <div className="grid grid-cols-2 gap-3">
                <div>
                  <label className="block text-xs font-semibold text-slate-300 mb-1">Doctor Name</label>
                  <input
                    type="text"
                    value={newRec.doctor_name}
                    onChange={(e) => setNewRec({ ...newRec, doctor_name: e.target.value })}
                    placeholder="Dr. Smith, MD"
                    className="w-full bg-slate-950 border border-slate-800 rounded-xl px-3 py-2 text-xs text-white focus:outline-none focus:border-cyan-500"
                  />
                </div>
                <div>
                  <label className="block text-xs font-semibold text-slate-300 mb-1">Clinic / Hospital</label>
                  <input
                    type="text"
                    value={newRec.facility}
                    onChange={(e) => setNewRec({ ...newRec, facility: e.target.value })}
                    placeholder="St. Jude Health"
                    className="w-full bg-slate-950 border border-slate-800 rounded-xl px-3 py-2 text-xs text-white focus:outline-none focus:border-cyan-500"
                  />
                </div>
              </div>

              <div className="p-3 bg-slate-950 rounded-2xl border border-slate-800 space-y-3">
                <span className="text-xs font-bold text-cyan-400">Clinical Measurements & Observations</span>
                
                <div className="grid grid-cols-2 sm:grid-cols-3 gap-2.5">
                  <div>
                    <label className="block text-[10px] text-slate-400">Systolic BP (mmHg)</label>
                    <input
                      type="number"
                      placeholder="120"
                      value={newRec.systolic_bp}
                      onChange={(e) => setNewRec({ ...newRec, systolic_bp: e.target.value })}
                      className="w-full bg-slate-900 border border-slate-800 rounded-lg p-1.5 text-xs text-white"
                    />
                  </div>
                  <div>
                    <label className="block text-[10px] text-slate-400">Diastolic BP (mmHg)</label>
                    <input
                      type="number"
                      placeholder="80"
                      value={newRec.diastolic_bp}
                      onChange={(e) => setNewRec({ ...newRec, diastolic_bp: e.target.value })}
                      className="w-full bg-slate-900 border border-slate-800 rounded-lg p-1.5 text-xs text-white"
                    />
                  </div>
                  <div>
                    <label className="block text-[10px] text-slate-400">Heart Rate (bpm)</label>
                    <input
                      type="number"
                      placeholder="72"
                      value={newRec.heart_rate}
                      onChange={(e) => setNewRec({ ...newRec, heart_rate: e.target.value })}
                      className="w-full bg-slate-900 border border-slate-800 rounded-lg p-1.5 text-xs text-white"
                    />
                  </div>
                  <div>
                    <label className="block text-[10px] text-slate-400">Fasting Glucose (mg/dL)</label>
                    <input
                      type="number"
                      placeholder="95"
                      value={newRec.blood_sugar_fasting}
                      onChange={(e) => setNewRec({ ...newRec, blood_sugar_fasting: e.target.value })}
                      className="w-full bg-slate-900 border border-slate-800 rounded-lg p-1.5 text-xs text-white"
                    />
                  </div>
                  <div>
                    <label className="block text-[10px] text-slate-400">Total Cholesterol (mg/dL)</label>
                    <input
                      type="number"
                      placeholder="190"
                      value={newRec.total_cholesterol}
                      onChange={(e) => setNewRec({ ...newRec, total_cholesterol: e.target.value })}
                      className="w-full bg-slate-900 border border-slate-800 rounded-lg p-1.5 text-xs text-white"
                    />
                  </div>
                  <div>
                    <label className="block text-[10px] text-slate-400">Oxygen SpO2 (%)</label>
                    <input
                      type="number"
                      placeholder="98"
                      value={newRec.spo2}
                      onChange={(e) => setNewRec({ ...newRec, spo2: e.target.value })}
                      className="w-full bg-slate-900 border border-slate-800 rounded-lg p-1.5 text-xs text-white"
                    />
                  </div>
                </div>
              </div>

              <div>
                <label className="block text-xs font-semibold text-slate-300 mb-1">Clinical Notes</label>
                <textarea
                  rows={2}
                  value={newRec.notes}
                  onChange={(e) => setNewRec({ ...newRec, notes: e.target.value })}
                  placeholder="Doctor instructions, findings, or observations..."
                  className="w-full bg-slate-950 border border-slate-800 rounded-xl p-2.5 text-xs text-white focus:outline-none focus:border-cyan-500"
                />
              </div>

              <div className="flex justify-end pt-2">
                <button
                  type="submit"
                  className="px-6 py-2.5 bg-cyan-500 hover:bg-cyan-400 text-slate-950 font-bold rounded-xl text-xs transition"
                >
                  Save Record Entry
                </button>
              </div>
            </form>
          </div>
        </div>
      )}

      {/* Modal 2: Upload Medical Report */}
      {showUploadModal && (
        <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-slate-950/85 backdrop-blur-md animate-fade-in no-print">
          <div className="bg-slate-900 border border-slate-700 rounded-3xl max-w-lg w-full p-6 sm:p-8 shadow-2xl text-white relative">
            <div className="flex items-center justify-between border-b border-slate-800 pb-3 mb-4">
              <h3 className="text-lg font-bold text-white flex items-center gap-2">
                <Upload className="w-5 h-5 text-emerald-400" /> Upload Medical Report / Document
              </h3>
              <button onClick={() => setShowUploadModal(false)} className="text-slate-400 hover:text-white">
                <X className="w-5 h-5" />
              </button>
            </div>

            <form onSubmit={handleUploadSubmit} className="space-y-4">
              <div>
                <label className="block text-xs font-semibold text-slate-300 mb-1">Report Title *</label>
                <input
                  type="text"
                  required
                  value={uploadTitle}
                  onChange={(e) => setUploadTitle(e.target.value)}
                  placeholder="e.g. Chest X-Ray Report, Blood Panel PDF"
                  className="w-full bg-slate-950 border border-slate-800 rounded-xl px-3 py-2 text-xs text-white focus:outline-none focus:border-cyan-500"
                />
              </div>

              <div className="grid grid-cols-2 gap-3">
                <div>
                  <label className="block text-xs font-semibold text-slate-300 mb-1">Doctor / Lab</label>
                  <input
                    type="text"
                    value={uploadDoctor}
                    onChange={(e) => setUploadDoctor(e.target.value)}
                    placeholder="Dr. Johnson"
                    className="w-full bg-slate-950 border border-slate-800 rounded-xl px-3 py-2 text-xs text-white"
                  />
                </div>
                <div>
                  <label className="block text-xs font-semibold text-slate-300 mb-1">Date</label>
                  <input
                    type="date"
                    value={uploadDate}
                    onChange={(e) => setUploadDate(e.target.value)}
                    className="w-full bg-slate-950 border border-slate-800 rounded-xl px-3 py-2 text-xs text-white"
                  />
                </div>
              </div>

              <div>
                <label className="block text-xs font-semibold text-slate-300 mb-1.5">Select PDF or Image Report File *</label>
                <input
                  type="file"
                  required
                  accept=".pdf,image/*"
                  onChange={(e) => setUploadFile(e.target.files[0])}
                  className="w-full text-xs text-slate-400 file:mr-3 file:py-2 file:px-4 file:rounded-xl file:border-0 file:text-xs file:font-semibold file:bg-slate-800 file:text-emerald-300 hover:file:bg-slate-700 cursor-pointer"
                />
              </div>

              <div>
                <label className="block text-xs font-semibold text-slate-300 mb-1">Notes / Summary</label>
                <textarea
                  rows={2}
                  value={uploadNotes}
                  onChange={(e) => setUploadNotes(e.target.value)}
                  placeholder="Key findings from the report..."
                  className="w-full bg-slate-950 border border-slate-800 rounded-xl p-2.5 text-xs text-white"
                />
              </div>

              <div className="flex justify-end pt-2">
                <button
                  type="submit"
                  disabled={uploading}
                  className="px-6 py-2.5 bg-emerald-500 hover:bg-emerald-400 text-slate-950 font-bold rounded-xl text-xs transition disabled:opacity-50"
                >
                  {uploading ? 'Uploading Document...' : 'Upload & Attach to Timeline'}
                </button>
              </div>
            </form>
          </div>
        </div>
      )}

    </div>
  );
};

export default EHRTimeline;
