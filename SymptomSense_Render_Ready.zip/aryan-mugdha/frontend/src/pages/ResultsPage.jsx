import React, { useState, useEffect, useRef } from 'react';
import { Link, useNavigate } from 'react-router-dom';
import { 
  Activity, 
  Download, 
  AlertTriangle, 
  CheckCircle2, 
  Share2, 
  ArrowLeft, 
  RotateCcw, 
  HeartHandshake, 
  UserCheck, 
  ShieldAlert, 
  Sparkles,
  ChevronRight,
  FileCheck,
  PhoneCall,
  Printer
} from 'lucide-react';
import ConfidenceBar from '../components/ConfidenceBar';
import ExplainabilityTree from '../components/ExplainabilityTree';
import EmergencyModal from '../components/EmergencyModal';
import { useAuth } from '../context/AuthContext';
import jsPDF from 'jspdf';
import html2canvas from 'html2canvas';

const ResultsPage = () => {
  const { user, isAuthenticated, showToast } = useAuth();
  const navigate = useNavigate();
  const reportRef = useRef(null);

  const [result, setResult] = useState(null);
  const [selectedConditionIdx, setSelectedConditionIdx] = useState(0);
  const [showEmergencyModal, setShowEmergencyModal] = useState(false);
  const [downloadingPdf, setDownloadingPdf] = useState(false);

  useEffect(() => {
    const raw = sessionStorage.getItem('symptomsense_latest_result');
    if (raw) {
      try {
        const parsed = JSON.parse(raw);
        setResult(parsed);
        if (parsed.is_emergency) {
          setShowEmergencyModal(true);
        }
      } catch (e) {
        console.error('Failed to parse result:', e);
      }
    }
  }, []);

  if (!result) {
    return (
      <div className="max-w-2xl mx-auto py-20 text-center space-y-4">
        <div className="w-12 h-12 rounded-2xl bg-cyan-500/20 text-cyan-400 flex items-center justify-center mx-auto">
          <Activity className="w-6 h-6 animate-spin" />
        </div>
        <h2 className="text-xl font-bold text-white">No Active Assessment Found</h2>
        <p className="text-xs text-slate-400">
          Run a symptom check to generate an explainable multi-modal health prediction.
        </p>
        <Link
          to="/checker"
          className="inline-flex items-center space-x-2 px-6 py-2.5 bg-cyan-500 hover:bg-cyan-400 text-slate-950 font-bold text-xs rounded-xl transition"
        >
          <RotateCcw className="w-4 h-4" />
          <span>Launch Symptom Checker</span>
        </Link>
      </div>
    );
  }

  const topCondition = result.predictions[0];
  const activeCondition = result.predictions[selectedConditionIdx] || topCondition;

  const handleExportPDF = async () => {
    if (!reportRef.current) return;
    setDownloadingPdf(true);
    showToast('Generating clinical PDF report...', 'info');

    try {
      const element = reportRef.current;
      const canvas = await html2canvas(element, {
        scale: 2,
        useCORS: true,
        backgroundColor: '#070D1E'
      });
      const imgData = canvas.toDataURL('image/png');
      const pdf = new jsPDF('p', 'mm', 'a4');
      const pdfWidth = pdf.internal.pageSize.getWidth();
      const pdfHeight = (canvas.height * pdfWidth) / canvas.width;

      pdf.addImage(imgData, 'PNG', 0, 0, pdfWidth, pdfHeight);
      pdf.save(`SymptomSense_Report_${topCondition.condition.replace(/[^a-zA-Z0-9]/g, '_')}.pdf`);
      showToast('PDF Report downloaded successfully!', 'success');
    } catch (err) {
      console.error('PDF export failed:', err);
      // Fallback to browser print dialog
      window.print();
    } finally {
      setDownloadingPdf(false);
    }
  };

  const getUrgencyClasses = (urg) => {
    switch (urg) {
      case 'Emergency':
        return {
          badge: 'bg-rose-500/25 text-rose-200 border-rose-500/60 shadow-lg shadow-rose-500/25 animate-pulse',
          card: 'border-rose-500/60 bg-rose-950/20 shadow-rose-500/10'
        };
      case 'High':
        return {
          badge: 'bg-amber-500/25 text-amber-200 border-amber-500/50 shadow-md shadow-amber-500/15',
          card: 'border-amber-500/50 bg-amber-950/20'
        };
      case 'Medium':
        return {
          badge: 'bg-yellow-500/20 text-yellow-200 border-yellow-500/40',
          card: 'border-yellow-500/40 bg-yellow-950/15'
        };
      case 'Low':
      default:
        return {
          badge: 'bg-emerald-500/20 text-emerald-200 border-emerald-500/40',
          card: 'border-emerald-500/40 bg-emerald-950/15'
        };
    }
  };

  const activeStyles = getUrgencyClasses(activeCondition.urgency);

  return (
    <div className="max-w-5xl mx-auto space-y-8 py-4">
      
      {/* Action Bar / Navigation */}
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4 no-print border-b border-slate-800 pb-4">
        <Link
          to="/checker"
          className="flex items-center space-x-1.5 text-xs font-semibold text-slate-400 hover:text-white transition"
        >
          <ArrowLeft className="w-4 h-4" />
          <span>New Symptom Check</span>
        </Link>

        <div className="flex items-center space-x-3">
          {result.is_emergency && (
            <button
              onClick={() => setShowEmergencyModal(true)}
              className="flex items-center space-x-1.5 px-3 py-1.5 bg-rose-600 hover:bg-rose-500 text-white rounded-xl text-xs font-bold transition shadow-lg shadow-rose-600/30 animate-pulse"
            >
              <AlertTriangle className="w-3.5 h-3.5" />
              <span>Emergency SOS</span>
            </button>
          )}

          <button
            onClick={handleExportPDF}
            disabled={downloadingPdf}
            className="flex items-center space-x-1.5 px-4 py-2 bg-slate-800 hover:bg-slate-700 text-slate-100 border border-slate-700 font-bold text-xs rounded-xl shadow-md transition disabled:opacity-50"
          >
            <Download className="w-3.5 h-3.5 text-cyan-400" />
            <span>{downloadingPdf ? 'Generating PDF...' : 'Export PDF Report'}</span>
          </button>

          <button
            onClick={() => window.print()}
            className="p-2 text-slate-400 hover:text-white hover:bg-slate-800 rounded-xl transition"
            title="Print Report"
          >
            <Printer className="w-4 h-4" />
          </button>
        </div>
      </div>

      {/* Printable Clinical Report Container */}
      <div ref={reportRef} className="space-y-8 p-1 sm:p-2">
        
        {/* Emergency Alert Banner if detected */}
        {result.is_emergency && (
          <div className="bg-gradient-to-r from-rose-950/70 via-red-950/60 to-rose-950/70 border-2 border-rose-500/80 rounded-3xl p-6 shadow-2xl shadow-rose-500/20 text-rose-100 flex flex-col md:flex-row items-center justify-between gap-4">
            <div className="space-y-1">
              <span className="text-[11px] font-bold uppercase tracking-wider text-rose-400 bg-rose-500/20 px-2.5 py-0.5 rounded-full border border-rose-500/40">
                Immediate Clinical Red Flag
              </span>
              <h3 className="text-lg font-bold text-white mt-1">Medical Attention Recommended Immediately</h3>
              <p className="text-xs text-rose-200">
                Triggered by: <strong>{result.emergency_trigger || 'Critical acute symptoms'}</strong>. Please proceed to the nearest emergency department.
              </p>
            </div>
            <a
              href="tel:911"
              className="flex-shrink-0 flex items-center space-x-2 px-5 py-2.5 bg-rose-600 hover:bg-rose-500 text-white font-bold text-xs rounded-xl shadow-lg transition"
            >
              <PhoneCall className="w-4 h-4" />
              <span>Call 911 / 112</span>
            </a>
          </div>
        )}

        {/* PRIMARY TOP PREDICTION CARD */}
        <div className={`glass-card p-6 sm:p-8 space-y-6 border-2 ${activeStyles.card} relative overflow-hidden`}>
          
          {/* Top Metadata Row */}
          <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4 border-b border-slate-800 pb-5">
            <div className="space-y-1">
              <div className="flex items-center space-x-2">
                <span className="text-[11px] font-extrabold uppercase tracking-wider text-cyan-400 bg-cyan-500/10 px-2.5 py-0.5 rounded-full border border-cyan-500/20">
                  Primary Differential ({activeCondition.rank} of {result.predictions.length})
                </span>
                <span className="text-[11px] font-mono text-slate-400 bg-slate-800/80 px-2 py-0.5 rounded border border-slate-700">
                  ICD-10: {activeCondition.icd10}
                </span>
              </div>
              <h1 className="text-2xl sm:text-3xl font-extrabold text-white tracking-tight">
                {activeCondition.condition}
              </h1>
              <p className="text-xs text-slate-400 font-medium">
                Category: <strong className="text-slate-300">{activeCondition.category}</strong> • Recommended Specialist: <strong className="text-cyan-300">{activeCondition.specialist}</strong>
              </p>
            </div>

            <div className="flex flex-col items-start sm:items-end space-y-1">
              <span className={`text-xs px-3 py-1 rounded-full border font-extrabold uppercase tracking-wider ${activeStyles.badge}`}>
                {activeCondition.urgency} Urgency
              </span>
              <span className="text-[11px] text-slate-400">
                Confidence Match: <strong className="text-white text-sm">{activeCondition.confidence}%</strong>
              </span>
            </div>
          </div>

          {/* Animated Confidence Bar */}
          <div className="space-y-2 bg-slate-950/60 p-4 rounded-2xl border border-slate-800/80">
            <ConfidenceBar confidence={activeCondition.confidence} urgency={activeCondition.urgency} size="lg" />
            <p className="text-[11px] text-slate-400 leading-relaxed pt-1">
              {activeCondition.description}
            </p>
          </div>

          {/* Clinical Management: Recommended Actions vs Home Care vs Red Flags */}
          <div className="grid grid-cols-1 md:grid-cols-3 gap-4 pt-2">
            
            {/* Recommended Medical Steps */}
            <div className="p-4 bg-slate-900/80 border border-slate-800 rounded-2xl space-y-2.5">
              <h4 className="text-xs font-bold uppercase tracking-wider text-cyan-400 flex items-center gap-1.5">
                <CheckCircle2 className="w-3.5 h-3.5" /> Next Steps & Clinical Testing
              </h4>
              <ul className="space-y-1.5 text-xs text-slate-300">
                {activeCondition.recommended_actions?.map((act, i) => (
                  <li key={i} className="flex items-start gap-2">
                    <span className="w-1.5 h-1.5 rounded-full bg-cyan-400 mt-1.5 flex-shrink-0"></span>
                    <span className="leading-relaxed">{act}</span>
                  </li>
                ))}
              </ul>
            </div>

            {/* Supportive Home Care */}
            <div className="p-4 bg-slate-900/80 border border-slate-800 rounded-2xl space-y-2.5">
              <h4 className="text-xs font-bold uppercase tracking-wider text-teal-400 flex items-center gap-1.5">
                <HeartHandshake className="w-3.5 h-3.5" /> Supportive Care & Relief
              </h4>
              <ul className="space-y-1.5 text-xs text-slate-300">
                {activeCondition.home_care?.map((care, i) => (
                  <li key={i} className="flex items-start gap-2">
                    <span className="w-1.5 h-1.5 rounded-full bg-teal-400 mt-1.5 flex-shrink-0"></span>
                    <span className="leading-relaxed">{care}</span>
                  </li>
                ))}
              </ul>
            </div>

            {/* Red Flag Warnings */}
            <div className="p-4 bg-slate-900/80 border border-rose-500/20 rounded-2xl space-y-2.5">
              <h4 className="text-xs font-bold uppercase tracking-wider text-rose-400 flex items-center gap-1.5">
                <ShieldAlert className="w-3.5 h-3.5" /> Red-Flag Symptoms
              </h4>
              <ul className="space-y-1.5 text-xs text-slate-300">
                {activeCondition.red_flags?.map((flag, i) => (
                  <li key={i} className="flex items-start gap-2">
                    <span className="w-1.5 h-1.5 rounded-full bg-rose-400 mt-1.5 flex-shrink-0"></span>
                    <span className="leading-relaxed">{flag}</span>
                  </li>
                ))}
              </ul>
            </div>

          </div>
        </div>

        {/* Explainability Section */}
        <ExplainabilityTree
          factors={result.explainability}
          conditionName={activeCondition.condition}
          patientSummary={result.patient_history_summary}
        />

        {/* Other Differential Conditions */}
        {result.predictions.length > 1 && (
          <div className="glass-card p-6 space-y-4">
            <div className="flex items-center justify-between border-b border-slate-800 pb-3">
              <h3 className="text-base font-bold text-white flex items-center gap-2">
                <Sparkles className="w-4 h-4 text-cyan-400" />
                Other Possible Differential Diagnoses
              </h3>
              <span className="text-xs text-slate-400">Click any card to inspect details</span>
            </div>

            <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-3">
              {result.predictions.map((p, idx) => (
                <button
                  key={idx}
                  onClick={() => setSelectedConditionIdx(idx)}
                  className={`p-4 rounded-2xl text-left transition flex flex-col justify-between space-y-2 border ${
                    selectedConditionIdx === idx
                      ? 'bg-cyan-500/15 border-cyan-500/60 shadow-md shadow-cyan-500/10'
                      : 'bg-slate-900/60 border-slate-800 hover:border-slate-700 hover:bg-slate-900'
                  }`}
                >
                  <div className="flex items-center justify-between w-full">
                    <span className="text-[10px] font-mono text-slate-400">#{p.rank}</span>
                    <span className={`text-[10px] px-2 py-0.5 rounded-full font-bold uppercase ${getUrgencyClasses(p.urgency).badge}`}>
                      {p.urgency}
                    </span>
                  </div>
                  <div>
                    <h4 className="text-xs font-bold text-white truncate">{p.condition}</h4>
                    <p className="text-[10px] text-slate-400">{p.specialist}</p>
                  </div>
                  <div className="w-full pt-1">
                    <div className="flex justify-between text-[10px] font-semibold text-slate-300 mb-1">
                      <span>Probability</span>
                      <span>{p.confidence}%</span>
                    </div>
                    <div className="w-full bg-slate-800 h-1.5 rounded-full overflow-hidden">
                      <div className="bg-cyan-400 h-full rounded-full" style={{ width: `${p.confidence}%` }} />
                    </div>
                  </div>
                </button>
              ))}
            </div>
          </div>
        )}

      </div>

      {/* Emergency Modal Instance */}
      <EmergencyModal
        isOpen={showEmergencyModal}
        onClose={() => setShowEmergencyModal(false)}
        triggerReason={result.emergency_trigger}
      />

    </div>
  );
};

export default ResultsPage;
