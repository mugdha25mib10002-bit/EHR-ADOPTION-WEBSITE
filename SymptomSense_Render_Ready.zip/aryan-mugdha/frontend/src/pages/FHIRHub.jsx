import React, { useState, useEffect } from 'react';
import { 
  Database, 
  Download, 
  Upload, 
  Copy, 
  Check, 
  RefreshCw, 
  FileCode, 
  Layers, 
  CheckCircle2, 
  ShieldCheck,
  ExternalLink
} from 'lucide-react';
import { fhirApi } from '../services/api';
import { useAuth } from '../context/AuthContext';

const FHIRHub = () => {
  const { user, showToast } = useAuth();
  const [bundle, setBundle] = useState(null);
  const [loading, setLoading] = useState(true);
  const [copied, setCopied] = useState(false);
  
  // Import state
  const [importJson, setImportJson] = useState('');
  const [importLoading, setImportLoading] = useState(false);
  const [importResult, setImportResult] = useState(null);

  useEffect(() => {
    fetchBundle();
  }, []);

  const fetchBundle = async () => {
    setLoading(true);
    try {
      const data = await fhirApi.exportBundle();
      setBundle(data);
    } catch (err) {
      showToast('Failed to generate FHIR Bundle: ' + err.message, 'error');
    } finally {
      setLoading(false);
    }
  };

  const handleDownload = () => {
    if (!bundle) return;
    const blob = new Blob([JSON.stringify(bundle, null, 2)], { type: 'application/json' });
    const url = URL.createObjectURL(blob);
    const a = document.createElement('a');
    a.href = url;
    a.download = `symptomsense_fhir_patient_${user?.id || 'record'}.json`;
    document.body.appendChild(a);
    a.click();
    document.body.removeChild(a);
    URL.revokeObjectURL(url);
    showToast('FHIR R4 Bundle downloaded!', 'success');
  };

  const handleCopy = () => {
    if (!bundle) return;
    navigator.clipboard.writeText(JSON.stringify(bundle, null, 2));
    setCopied(true);
    setTimeout(() => setCopied(false), 2500);
    showToast('Copied FHIR JSON to clipboard!', 'success');
  };

  const handleImport = async () => {
    if (!importJson.trim()) {
      showToast('Please paste valid FHIR JSON payload.', 'error');
      return;
    }
    setImportLoading(true);
    try {
      const parsed = JSON.parse(importJson);
      const res = await fhirApi.importBundle(parsed);
      setImportResult(res);
      showToast(`Imported ${res.records_imported} FHIR resources!`, 'success');
      fetchBundle();
    } catch (err) {
      showToast('Import Error: ' + err.message, 'error');
    } finally {
      setImportLoading(false);
    }
  };

  return (
    <div className="max-w-5xl mx-auto space-y-8 py-4">
      
      {/* Page Header */}
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4 border-b border-slate-800 pb-4">
        <div className="space-y-1">
          <div className="flex items-center space-x-2 text-indigo-400 text-xs font-bold uppercase tracking-wider">
            <Database className="w-4 h-4" />
            <span>Healthcare Interoperability</span>
          </div>
          <h1 className="text-2xl sm:text-3xl font-extrabold text-white tracking-tight">
            HL7 FHIR R4 Data Exchange Hub
          </h1>
          <p className="text-xs text-slate-400">
            Export and import hospital-grade Fast Healthcare Interoperability Resources (FHIR R4) standard bundles.
          </p>
        </div>

        <div className="flex items-center space-x-2 self-start sm:self-auto">
          <button
            onClick={handleCopy}
            disabled={loading || !bundle}
            className="flex items-center space-x-1.5 px-3 py-2 bg-slate-800 hover:bg-slate-700 text-slate-200 border border-slate-700 rounded-xl text-xs font-bold transition disabled:opacity-50"
          >
            {copied ? <Check className="w-3.5 h-3.5 text-emerald-400" /> : <Copy className="w-3.5 h-3.5" />}
            <span>{copied ? 'Copied' : 'Copy JSON'}</span>
          </button>
          <button
            onClick={handleDownload}
            disabled={loading || !bundle}
            className="flex items-center space-x-1.5 px-4 py-2 bg-gradient-to-r from-indigo-500 to-cyan-500 hover:from-indigo-400 hover:to-cyan-400 text-slate-950 font-bold text-xs rounded-xl shadow-lg shadow-indigo-500/20 transition disabled:opacity-50"
          >
            <Download className="w-3.5 h-3.5" />
            <span>Download .JSON</span>
          </button>
        </div>
      </div>

      {/* Standards Feature Grid */}
      <div className="grid grid-cols-1 md:grid-cols-4 gap-4">
        <div className="glass-card p-4 space-y-1 border-slate-800">
          <span className="text-[10px] font-bold text-indigo-400 uppercase tracking-wider">Resource Type</span>
          <h3 className="text-sm font-bold text-white">Patient</h3>
          <p className="text-[11px] text-slate-400">Demographics, biological sex, identifiers, blood group extension.</p>
        </div>
        <div className="glass-card p-4 space-y-1 border-slate-800">
          <span className="text-[10px] font-bold text-cyan-400 uppercase tracking-wider">Resource Type</span>
          <h3 className="text-sm font-bold text-white">Condition</h3>
          <p className="text-[11px] text-slate-400">Problem list items, ICD-10 clinical diagnosis mappings.</p>
        </div>
        <div className="glass-card p-4 space-y-1 border-slate-800">
          <span className="text-[10px] font-bold text-teal-400 uppercase tracking-wider">Resource Type</span>
          <h3 className="text-sm font-bold text-white">Observation</h3>
          <p className="text-[11px] text-slate-400">LOINC-standard laboratory test values & vital sign telemetry.</p>
        </div>
        <div className="glass-card p-4 space-y-1 border-slate-800">
          <span className="text-[10px] font-bold text-emerald-400 uppercase tracking-wider">Resource Type</span>
          <h3 className="text-sm font-bold text-white">MedicationStatement</h3>
          <p className="text-[11px] text-slate-400">Active prescription regimens, dosages, and administration schedules.</p>
        </div>
      </div>

      {/* Interactive JSON Viewer */}
      <div className="glass-card p-6 space-y-4">
        <div className="flex items-center justify-between border-b border-slate-800 pb-3">
          <div className="flex items-center space-x-2">
            <FileCode className="w-4 h-4 text-cyan-400" />
            <h3 className="text-sm font-bold text-white">Live FHIR R4 Bundle Payload</h3>
          </div>
          <span className="text-xs text-slate-400 font-mono">
            {bundle?.entry?.length || 0} Total Entries Serialized
          </span>
        </div>

        {loading ? (
          <div className="py-24 text-center space-y-2">
            <RefreshCw className="w-8 h-8 animate-spin text-cyan-400 mx-auto" />
            <p className="text-xs text-slate-400">Compiling patient electronic health records into FHIR JSON...</p>
          </div>
        ) : (
          <pre className="bg-slate-950 p-5 rounded-2xl border border-slate-800 text-[11px] font-mono text-cyan-300 overflow-x-auto max-h-[420px] custom-scrollbar leading-relaxed">
            {JSON.stringify(bundle, null, 2)}
          </pre>
        )}
      </div>

      {/* FHIR Import Section */}
      <div className="glass-card p-6 sm:p-8 space-y-4">
        <div className="flex items-center space-x-2 border-b border-slate-800 pb-3">
          <Upload className="w-4 h-4 text-teal-400" />
          <h3 className="text-base font-bold text-white">Import External FHIR Bundle (Hospital / Lab EHR)</h3>
        </div>

        <p className="text-xs text-slate-400 leading-relaxed">
          Paste any FHIR R4 JSON Bundle from your healthcare provider, hospital portal, or external laboratory system to automatically populate your health profile and vital records.
        </p>

        <textarea
          rows={6}
          value={importJson}
          onChange={(e) => setImportJson(e.target.value)}
          placeholder='{"resourceType": "Bundle", "type": "collection", "entry": [...] }'
          className="w-full bg-slate-950 border border-slate-800 rounded-2xl p-3.5 text-xs font-mono text-cyan-300 focus:outline-none focus:border-teal-500 custom-scrollbar"
        />

        {importResult && (
          <div className="p-4 bg-emerald-950/40 border border-emerald-500/40 rounded-2xl text-xs text-emerald-200 space-y-1.5">
            <div className="font-bold text-emerald-300 flex items-center gap-1.5">
              <CheckCircle2 className="w-4 h-4" /> FHIR Synchronization Complete
            </div>
            <p>Imported {importResult.records_imported} observation records.</p>
            <ul className="list-disc list-inside text-[11px] text-emerald-300/80">
              {importResult.details?.map((d, i) => (
                <li key={i}>{d}</li>
              ))}
            </ul>
          </div>
        )}

        <div className="flex justify-end pt-1">
          <button
            onClick={handleImport}
            disabled={importLoading || !importJson.trim()}
            className="flex items-center space-x-2 px-6 py-2.5 bg-teal-500 hover:bg-teal-400 text-slate-950 font-bold rounded-xl text-xs shadow-lg shadow-teal-500/20 transition disabled:opacity-50"
          >
            {importLoading ? <RefreshCw className="w-4 h-4 animate-spin" /> : <Upload className="w-4 h-4" />}
            <span>{importLoading ? 'Importing Data...' : 'Import & Synchronize'}</span>
          </button>
        </div>
      </div>

    </div>
  );
};

export default FHIRHub;
