import React, { useState } from 'react';
import { useNavigate } from 'react-router-dom';
import { 
  ShieldCheck, 
  Lock, 
  Trash2, 
  CheckCircle2, 
  AlertTriangle, 
  FileText, 
  Key, 
  Server, 
  EyeOff, 
  RotateCcw 
} from 'lucide-react';
import { authApi } from '../services/api';
import { useAuth } from '../context/AuthContext';

const PrivacySecurity = () => {
  const { user, logout, showToast, isAuthenticated } = useAuth();
  const navigate = useNavigate();

  const [consentGiven, setConsentGiven] = useState(user?.consent_given ?? true);
  const [updatingConsent, setUpdatingConsent] = useState(false);
  const [showDeleteConfirm, setShowDeleteConfirm] = useState(false);
  const [deleting, setDeleting] = useState(false);

  const handleConsentToggle = async (e) => {
    const val = e.target.checked;
    setConsentGiven(val);
    if (isAuthenticated) {
      setUpdatingConsent(true);
      try {
        await authApi.updateConsent(val);
        showToast(val ? 'Consent recorded.' : 'Consent revoked.', 'info');
      } catch (err) {
        showToast('Failed to update consent: ' + err.message, 'error');
      } finally {
        setUpdatingConsent(false);
      }
    }
  };

  const handleDeleteData = async () => {
    setDeleting(true);
    try {
      await authApi.deleteMyData();
      showToast('All your health records and account have been permanently erased.', 'success');
      logout();
      navigate('/');
    } catch (err) {
      showToast('Data deletion error: ' + err.message, 'error');
    } finally {
      setDeleting(false);
      setShowDeleteConfirm(false);
    }
  };

  return (
    <div className="max-w-4xl mx-auto space-y-8 py-4">
      
      {/* Page Header */}
      <div className="space-y-1 border-b border-slate-800 pb-4">
        <div className="flex items-center space-x-2 text-emerald-400 text-xs font-bold uppercase tracking-wider">
          <ShieldCheck className="w-4 h-4" />
          <span>Patient Trust & Compliance</span>
        </div>
        <h1 className="text-2xl sm:text-3xl font-extrabold text-white tracking-tight">
          Privacy, Encryption & Safety Controls
        </h1>
        <p className="text-xs text-slate-400">
          SymptomSense adheres to strict data privacy principles with zero third-party commercial data sharing.
        </p>
      </div>

      {/* Security Architecture Grid */}
      <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
        <div className="glass-card p-5 space-y-2 border-slate-800">
          <div className="w-9 h-9 rounded-xl bg-emerald-500/20 text-emerald-400 flex items-center justify-center">
            <Lock className="w-5 h-5" />
          </div>
          <h3 className="text-sm font-bold text-white">Encryption at Rest & Transit</h3>
          <p className="text-xs text-slate-400 leading-relaxed">
            All database storage is encrypted with industry-standard AES-256 and transmitted over TLS 1.3 encrypted HTTPS tunnels.
          </p>
        </div>

        <div className="glass-card p-5 space-y-2 border-slate-800">
          <div className="w-9 h-9 rounded-xl bg-cyan-500/20 text-cyan-400 flex items-center justify-center">
            <Key className="w-5 h-5" />
          </div>
          <h3 className="text-sm font-bold text-white">Role-Based Access (RBAC)</h3>
          <p className="text-xs text-slate-400 leading-relaxed">
            JWT-based private token architecture prevents cross-tenant data leakage. Only you hold authorization to view your records.
          </p>
        </div>

        <div className="glass-card p-5 space-y-2 border-slate-800">
          <div className="w-9 h-9 rounded-xl bg-teal-500/20 text-teal-400 flex items-center justify-center">
            <EyeOff className="w-5 h-5" />
          </div>
          <h3 className="text-sm font-bold text-white">De-Identification</h3>
          <p className="text-xs text-slate-400 leading-relaxed">
            ML feature vectors strip personal identifiable information (PII) before calculating model inferences.
          </p>
        </div>
      </div>

      {/* Active Consent Management */}
      <div className="glass-card p-6 sm:p-8 space-y-4 border-emerald-500/30">
        <div className="flex items-center justify-between border-b border-slate-800 pb-3">
          <div className="flex items-center space-x-2">
            <FileText className="w-4 h-4 text-emerald-400" />
            <h3 className="text-base font-bold text-white">Patient Consent & Data Processing Authorization</h3>
          </div>
          <span className="text-xs text-emerald-400 font-semibold bg-emerald-500/10 px-3 py-1 rounded-full border border-emerald-500/20">
            Active Status
          </span>
        </div>

        <p className="text-xs text-slate-300 leading-relaxed">
          I consent to SymptomSense securely analyzing my active symptoms and stored EHR health profile for the purpose of estimating condition risk probabilities and generating clinical next-step guidance.
        </p>

        <div className="flex items-center justify-between bg-slate-950/80 p-4 rounded-2xl border border-slate-800">
          <span className="text-xs font-semibold text-slate-200">
            Store & Process Electronic Health Record Data
          </span>
          <label className="relative inline-flex items-center cursor-pointer">
            <input
              type="checkbox"
              checked={consentGiven}
              onChange={handleConsentToggle}
              disabled={updatingConsent}
              className="sr-only peer"
            />
            <div className="w-11 h-6 bg-slate-800 peer-focus:outline-none rounded-full peer peer-checked:after:translate-x-full peer-checked:after:border-white after:content-[''] after:absolute after:top-[2px] after:left-[2px] after:bg-white after:border-slate-300 after:border after:rounded-full after:h-5 after:w-5 after:transition-all peer-checked:bg-emerald-500"></div>
          </label>
        </div>

        {user?.consent_timestamp && (
          <p className="text-[11px] text-slate-500">
            Last consent update recorded on: {new Date(user.consent_timestamp).toLocaleString()}
          </p>
        )}
      </div>

      {/* Mandatory Clinical Disclaimer Card */}
      <div className="glass-card p-6 sm:p-8 space-y-3 border-amber-500/30 bg-amber-950/10">
        <div className="flex items-center space-x-2 text-amber-300">
          <AlertTriangle className="w-5 h-5 text-amber-400" />
          <h3 className="text-base font-bold">Official Clinical Notice & Limitations</h3>
        </div>
        <p className="text-xs text-slate-300 leading-relaxed">
          SymptomSense is an assistive clinical intelligence software. It does <strong className="text-amber-200">not</strong> replace an in-person physical examination, medical consultation, or diagnostic laboratory testing by a qualified physician. Always consult a licensed medical professional for formal diagnoses and before starting or stopping any medication.
        </p>
      </div>

      {/* Delete My Data Purge Section */}
      {isAuthenticated && (
        <div className="glass-card p-6 sm:p-8 space-y-4 border-rose-500/30 bg-rose-950/10">
          <div className="flex items-center space-x-2 text-rose-400 border-b border-slate-800 pb-3">
            <Trash2 className="w-4 h-4" />
            <h3 className="text-base font-bold text-white">Right to Erasure (GDPR / HIPAA Purge)</h3>
          </div>

          <p className="text-xs text-slate-300 leading-relaxed">
            Permanently delete your account, patient profile, all logged vitals, lab reports, and assessment history. This action cannot be undone.
          </p>

          <button
            onClick={() => setShowDeleteConfirm(true)}
            className="px-5 py-2.5 bg-rose-600/20 hover:bg-rose-600 text-rose-300 hover:text-white border border-rose-500/40 rounded-xl text-xs font-bold transition duration-200"
          >
            Delete My Health Data & Account
          </button>
        </div>
      )}

      {/* Confirmation Modal */}
      {showDeleteConfirm && (
        <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-slate-950/85 backdrop-blur-md animate-fade-in no-print">
          <div className="bg-slate-900 border border-rose-500/70 rounded-3xl max-w-md w-full p-6 text-white space-y-4 shadow-2xl">
            <div className="flex items-center space-x-3 text-rose-400">
              <AlertTriangle className="w-6 h-6" />
              <h3 className="text-lg font-bold">Confirm Permanent Deletion</h3>
            </div>
            <p className="text-xs text-slate-300 leading-relaxed">
              Are you sure you want to permanently erase your entire electronic health profile, history records, and account? This action is irreversible.
            </p>
            <div className="flex justify-end space-x-3 pt-2">
              <button
                onClick={() => setShowDeleteConfirm(false)}
                className="px-4 py-2 bg-slate-800 hover:bg-slate-700 text-slate-300 rounded-xl text-xs font-bold"
              >
                Cancel
              </button>
              <button
                onClick={handleDeleteData}
                disabled={deleting}
                className="px-5 py-2 bg-rose-600 hover:bg-rose-500 text-white rounded-xl text-xs font-bold shadow-lg shadow-rose-600/30"
              >
                {deleting ? 'Erasing...' : 'Yes, Delete Everything'}
              </button>
            </div>
          </div>
        </div>
      )}

    </div>
  );
};

export default PrivacySecurity;
